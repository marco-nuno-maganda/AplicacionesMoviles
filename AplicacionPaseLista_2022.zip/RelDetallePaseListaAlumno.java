package com.example.aplicacionpaselista_2022;

/**
 * Created by marco on 22/04/16.
 */

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class RelDetallePaseListaAlumno {
    private int id_DetallePaseLista;
    private int id_paselista;
    private int id_GrupoAlumno;
    private String nombre_alumno;
    private int  Estatus;

    public RelDetallePaseListaAlumno(int iddpl, int idpl, int idga, String na, int est) {
        this.id_DetallePaseLista = iddpl;
        this.id_paselista = idpl;
        this.id_GrupoAlumno = idga;
        this.nombre_alumno =na;
        this.Estatus = est;
    }
    // getters and setters
    public int getIddpl () { return this.id_DetallePaseLista; }
    public int getIdpl () { return this.id_paselista; }
    public int getIdga () { return this.id_GrupoAlumno; }
    public String getName () { return this.nombre_alumno; }
    public int getEstatus () { return this.Estatus; }



    public String toString() {
        return String.format("%d\t%d\t%d\t%s\t", id_DetallePaseLista, id_paselista, id_GrupoAlumno, nombre_alumno);
    }
}


class RelDetallePaseListaAlumnoChainedComparator implements Comparator<RelDetallePaseListaAlumno> {

    private List<Comparator<RelDetallePaseListaAlumno>> listComparators;

    @SafeVarargs
    public RelDetallePaseListaAlumnoChainedComparator(Comparator<RelDetallePaseListaAlumno>... comparators) {
        this.listComparators = Arrays.asList(comparators);
    }

    @Override
    public int compare(RelDetallePaseListaAlumno emp1, RelDetallePaseListaAlumno emp2) {
        for (Comparator<RelDetallePaseListaAlumno> comparator : listComparators) {
            int result = comparator.compare(emp1, emp2);
            if (result != 0) {
                return result;
            }
        }
        return 0;
    }
}

class RelDetallePaseListaAlumnoNameComparator implements Comparator<RelDetallePaseListaAlumno> {
    @Override
    public int compare(RelDetallePaseListaAlumno emp1, RelDetallePaseListaAlumno emp2) {
        return emp1.getName().compareTo(emp2.getName());
    }
}
