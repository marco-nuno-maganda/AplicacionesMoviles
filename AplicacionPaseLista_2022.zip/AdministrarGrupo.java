package com.example.aplicacionpaselista_2022;

/* Consideraciones Importante:
- Generar la versión Release (FIRMADA) de la aplicación
http://developer.android.com/intl/es/tools/publishing/app-signing.html

- Generar la versión alineada con la utileria zipalign (la versión que se somete
http://android-developers.blogspot.mx/2009/09/zipalign-easy-optimization.html

 */

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.format.Time;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by marco on 26/08/15.
 */
public class AdministrarGrupo extends Activity {

    String Nombre_Grupo;
    String ID_Grupo;

    public ArrayList<Grupo> ArregloObjetos_Grupos; //= new ArrayList<Grupo>();
    BaseDatosGAA ObjetoBaseDatosGAA;
    SQLiteDatabase BaseDatos01;
    //Cursor cursor;
    Cursor cursor2;
    Cursor cursorXX;
    Cursor cursorGG;
    Cursor cursorHH;
    Cursor cursorNN;
    Cursor HH;
    Cursor cursorFF;
    Cursor cursorZZ;
    Cursor cursorRR;
    final String TABLA_PRINCIPALA = "Grupos";
    //final String NOMBRE_BASE_DATOS = "Experimento07.db";
    final String NOMBRE_BASE_DATOS = "Basedatos001.db";

    //TextView TV1, TV2, TV3, TV4, TV5;
    TextView TV1;
    Spinner SP1;
    Button BotonGuardarAsistencia, BotonFaltaAsistenciaTodos, BotonSalirAChingarASuMadre;
    //Button B7, B8;

    AdaptadorGrupoFormularioAdministrar adapter_Grupo;
    AdministrarGrupo MX;

    int Dia, Mes, Anno;
    String CadenaFecha;


    public ArrayList<PaseLista_DetalleLista> ArregloObjetos_ListView_PaseLista_DetalleLista;
    MyCustomAdapter dataAdapter = null;
    ListView listView;
    Boolean EstadoInicial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actividad_administrargrupo);

        EstadoInicial=false;

        ArregloObjetos_ListView_PaseLista_DetalleLista = new ArrayList<PaseLista_DetalleLista>();



        String ArchivoDB = NOMBRE_BASE_DATOS;
        ObjetoBaseDatosGAA = new BaseDatosGAA(this, ArchivoDB, null, 1);
        BaseDatos01 = ObjetoBaseDatosGAA.getWritableDatabase();


        MX = this;
        TV1 = (TextView) findViewById(R.id.tv_localidad);

        //TV2 = (TextView) findViewById(R.id.tv_temporal1);
        //TV3 = (TextView) findViewById(R.id.tv_temporal2);
        //TV4 = (TextView) findViewById(R.id.tv_temporal3);
        //TV5 = (TextView) findViewById(R.id.tv_temporal4);
        listView = (ListView) findViewById(R.id.listView1);

        //B6 = (Button) findViewById(R.id.BT6);
        //B7 = (Button) findViewById(R.id.BT7);
        //B8 = (Button) findViewById(R.id.BT8);
        BotonGuardarAsistencia = (Button) findViewById(R.id.B0);
        BotonFaltaAsistenciaTodos = (Button) findViewById(R.id.FaltaAsistencia);
        BotonSalirAChingarASuMadre = (Button) findViewById(R.id.BotonAChingaAsuMadre);


        Bundle extras = getIntent().getExtras();
        if (extras!= null)
        { // SE llamo desde otro formulario con algun parametro...
            Dia = extras.getInt("Dia");
            Mes = extras.getInt("Mes");
            Anno = extras.getInt("Anno");
            TV1.setText("Fecha: "+Dia+"/"+Mes+"/"+Anno);
        }
        else
        {
            // Fecha de HOY !°
            Time today;
            today = new Time(Time.getCurrentTimezone());
            today.setToNow();
            Dia = today.monthDay;
            Mes = today.month;
            Anno = today.year;
            TV1.setText("Fecha: "+Dia+"/"+Mes+"/"+Anno);
        }


        BotonFaltaAsistenciaTodos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Recorrer el arreglo y asignar el estatus de verdadero o falso
                for (int i=0; i<ArregloObjetos_ListView_PaseLista_DetalleLista.size(); i++) {

                    if (EstadoInicial) {
                        ArregloObjetos_ListView_PaseLista_DetalleLista.get(i).setSelected(true);
                        ArregloObjetos_ListView_PaseLista_DetalleLista.get(i).setSelected2(false);
                    } else {
                        ArregloObjetos_ListView_PaseLista_DetalleLista.get(i).setSelected(false);
                        ArregloObjetos_ListView_PaseLista_DetalleLista.get(i).setSelected2(false);
                    }


                    dataAdapter = new MyCustomAdapter(MX, R.layout.fila_listview_administrar_grupo, ArregloObjetos_ListView_PaseLista_DetalleLista, MX);
                    // Asignar el adaptador al ListView
                    listView.setAdapter(dataAdapter);


                }

                EstadoInicial = (EstadoInicial ? false : true);
            }
        });
        // Resetear Pase de Lista
/*        B6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });*/


        // Resetear Pase de Lista
/*        B7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
*/

        BotonSalirAChingarASuMadre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Guardar antes (A la de a Wildford si)
                // Terminar
                GuardarAsistenciasBD();
                finish ();
            }
        });

        CadenaFecha=""+Anno+""+(Mes < 10 ? "0"+Mes : Mes )+""+(Dia < 10 ? "0"+Dia : Dia );


        SP1 = (Spinner) findViewById (R.id.sp_localidad);
        ArregloObjetos_Grupos = new ArrayList<Grupo>();
        ConsultarGrupos();
        adapter_Grupo = new AdaptadorGrupoFormularioAdministrar(MX, R.layout.fila_spinner_personal, ArregloObjetos_Grupos);
        adapter_Grupo.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);
        SP1.setAdapter(adapter_Grupo);
        SP1.setSelection(0);

        ConsultarAsistencias();



        SP1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View v, int position, long id) {
                Nombre_Grupo = ((TextView) v.findViewById(R.id.tv_nombre)).getText().toString();
                ID_Grupo = ((TextView) v.findViewById(R.id.tv_apellido)).getText().toString();

                // Detonar la busqueda para buscar a los alumnos que pertenezcan a este Grupo
                int id_grupo = ("".equals(ID_Grupo.toString().trim()) ? 0 : Integer.parseInt(ID_Grupo.toString().trim()));
                ConsultaGrupo_Alumno_Avanzada(id_grupo);
                int Fecha = ("".equals(CadenaFecha.toString().trim()) ? 0 : Integer.parseInt(CadenaFecha.toString().trim()));

                //Toast.makeText(getApplicationContext(), "GRUPO: "+ id_grupo, Toast.LENGTH_LONG).show();
                // Obtener id Pase Lista

                //id_paselista = ObtieneID_PaseLista(id_grupo, Fecha);
                int Id_Paselista = ObtieneID_PaseLista (id_grupo, Fecha);
                if (Id_Paselista == 0) {   // Crear el pase de lista ...
                    ContentValues valuesX;
                    valuesX = new ContentValues();
                    valuesX.put("id_grupo ", id_grupo);
                    valuesX.put("fecha_asistencia", Fecha);
                    long id_PaseLista = BaseDatos01.insert("PaseLista", null, valuesX);
                    CrearDetalleLista((int) id_PaseLista, id_grupo);
                    ConsultarAsistencias(); // Actualizar el cuadrito temporal de asistencias
                    //Toast.makeText(getApplicationContext(), "No había pase de lista, se creó \n Ultimo ID Creado" + id_PaseLista, Toast.LENGTH_SHORT).show();

                } // Si habia el pase de lista -> Consultar los pases de lis
                else {
                    ConsultaDetalleLista_ConAlumno(Id_Paselista);

                }
                dataAdapter = new MyCustomAdapter(MX, R.layout.fila_listview_administrar_grupo, ArregloObjetos_ListView_PaseLista_DetalleLista ,MX);
                // Asignar el adaptador al ListView
                listView.setAdapter(dataAdapter);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }


        });


        SP1.setOnTouchListener(new Spinner.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getAction();
                switch (action) {
                    case MotionEvent.ACTION_DOWN:
                        v.getParent().requestDisallowInterceptTouchEvent(true);
                        break;
                    case MotionEvent.ACTION_UP:
                        v.getParent().requestDisallowInterceptTouchEvent(false);
                        break;

                }
                v.onTouchEvent(event);
                return true;
            }
        });


        // GUARDAR LISTA (Leer del Arreglo de Objetos e Insertar en el Detalle de Lista
        BotonGuardarAsistencia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Explicitamente respalda la información de las asistencias mostradas en la BD
                GuardarAsistenciasBD();
                // Tambien en la tecla BACK
            }
        });


        //ConsultarGrupos ();
    }

    @Override
    public void onBackPressed() {
        // your code.
        GuardarAsistenciasBD();
        finish();
    }

    /*
    * Lee
    *
    * */

    void GuardarAsistenciasBD () {


        //BotonGuardarAsistencia.setEnabled(false);
        //BotonFaltaAsistenciaTodos.setEnabled(false);
        //BotonSalirAChingarASuMadre.setEnabled(false);

        int ContadorAlumnos=0;
        int ContadorAsistencias=0;
        String Cadena="";
        for (int i=0; i<ArregloObjetos_ListView_PaseLista_DetalleLista.size(); i++) {
            //Cadena += ArregloObjetos_ListView_PaseLista_DetalleLista.get(i).toString() + "\n";

            Cadena += ArregloObjetos_ListView_PaseLista_DetalleLista.get(i).toString() + "--" + ArregloObjetos_ListView_PaseLista_DetalleLista.get(i).get_estatus() +"\n";

            //Actualizamos el registro en la base de datos
            ContentValues valores = new ContentValues();
            valores.put("Estatus", "" + ArregloObjetos_ListView_PaseLista_DetalleLista.get(i).get_estatus());
            BaseDatos01.update("DetallePaseLista", valores, "_id=" + ArregloObjetos_ListView_PaseLista_DetalleLista.get(i).get_id(), null);
            ContadorAlumnos++;
            ContadorAsistencias+=(ArregloObjetos_ListView_PaseLista_DetalleLista.get(i).get_estatus()>0 ? 1 : 0);
        }

        //ConsultarAsistencias();
        //ConsultaDetalleLista(ArregloObjetos_ListView_PaseLista_DetalleLista.get(0).get_id_PaseLista());

        // Resultado del pase ...
        //Toast.makeText(getApplicationContext(), "Estatus del Pase " +Cadena, Toast.LENGTH_LONG).show();
        Toast.makeText(getApplicationContext(), "Guardando Informacion de Asistencias ----\nAlumnos del Grupo " + ContadorAlumnos + "\n" + "Asistencias: " + ContadorAsistencias, Toast.LENGTH_LONG).show();
    }

    int ObtieneID_PaseLista (int id_grupo, int Fecha) {
        int id_PaseLista  = 0;

        cursorNN = BaseDatos01.rawQuery("select * from PaseLista where id_grupo = " + id_grupo + " and fecha_asistencia = " + Fecha, null);
        //int ExistePaseLista = 1;
        if (cursorNN.getCount() != 0) {
            // Cargar NNPase de Lista Previo
            if (cursorNN.moveToFirst()) {
                String C1 = "";
                do {
                    C1 += cursorNN.getString(cursorNN.getColumnIndex("_id"));

                } while (cursorNN.moveToNext());
                id_PaseLista = ("".equals(C1.toString().trim()) ? 0 : Integer.parseInt(C1.toString().trim()));
                //Toast.makeText(getApplicationContext(), "Hay pase de lista, su ID es: " + id_PaseLista, Toast.LENGTH_SHORT).show();

                //ConsultaDetalleLista(id_PaseLista);
                //ConsultaDetalleLista_ConAlumno(id_PaseLista);

            }
        }
        return (id_PaseLista);
    }


    void CrearDetalleLista (int id_paselista, int id_grupo) {

        List<RelDetallePaseListaAlumno> listRelDetallePaseListaAlumnos = new ArrayList<RelDetallePaseListaAlumno>();

        //TV5.setText("Elementos en la Consulta de Grupos: ");
        long id_DetallePaseLista;
        // Consulta Grupo-Alumno con Nombre de Grupo y Nombre de Alumno
        String SELECT_QUERY = "SELECT * FROM Grupos t1 INNER JOIN GrupoAlumno t2 ON t1._id = t2.id_grupo and t1._id = "+id_grupo +" INNER JOIN Alumnos T3 on t3._id = t2.id_alumno";
        cursorRR = BaseDatos01.rawQuery(SELECT_QUERY, null);

        // Cada consulta se crea un arreglo de objetos nuevo
        ArregloObjetos_ListView_PaseLista_DetalleLista = new ArrayList<PaseLista_DetalleLista>();

        if (cursorRR.getCount() != 0) {
            if (cursorRR.moveToFirst()) {
                do {
                    // COLUMNAS de la CONSULTA:
                    //    0             1               2              3           4           5          6
                    // ID_GRUPO  - NOMBREGRUPO - ID_GRUPO_ALUMNO - ID_GRUPO - ID_ALUMNO - ID-ALUMNO - NOMBREALUMNO

                    // Obtener id_Alumno y Nombre
                    int id_grupo_alumno= 0; //Integer.parseInt(ET3.getText().toString().trim());
                    id_grupo_alumno = ("".equals(cursorRR.getString(2).toString().trim()) ? 0 : Integer.parseInt(cursorRR.getString(2).toString().trim()));
                    String Nombre = cursorRR.getString(6).toString().trim();

                    //TV5.append("VALIO CHINGADA : !!!! "+"\n");

                    // Insertar el Alumno
                    ContentValues valuesXX;
                    valuesXX= new ContentValues();
                    valuesXX.put("id_paselista",id_paselista);
                    valuesXX.put("id_GrupoAlumno",id_grupo_alumno);
                    valuesXX.put("Estatus",0); // FALTA POR DEFECTO
                    id_DetallePaseLista = BaseDatos01.insert("DetallePaseLista",null,valuesXX);

                    if (id_DetallePaseLista < 0) {
                     //   TV5.append("VALIO CHINGADA : !!!! " + "\n");
                    }

                    // Crear la Tabla que Alimentará el ListView
                    //PaseLista_DetalleLista OBJ_Temporal = new PaseLista_DetalleLista((int)id_DetallePaseLista,id_paselista,id_grupo_alumno,Nombre,0);
                    //ArregloObjetos_ListView_PaseLista_DetalleLista.add(OBJ_Temporal);

                    listRelDetallePaseListaAlumnos.add(new RelDetallePaseListaAlumno((int)id_DetallePaseLista, id_paselista, id_grupo_alumno, Nombre, 0));




                    //TV5.append(""+OBJ_Temporal);
                } while (cursorRR.moveToNext());
            }
        }
        cursorRR.close();

// Ordenar el listado por nombre...
        Collections.sort(listRelDetallePaseListaAlumnos, new RelDetallePaseListaAlumnoChainedComparator(
                        new RelDetallePaseListaAlumnoNameComparator())
        );

        int ConteoEstudiantes=1;
        for (RelDetallePaseListaAlumno emp : listRelDetallePaseListaAlumnos) {
            //System.out.println(emp);
            PaseLista_DetalleLista OBJ_Temporal = new PaseLista_DetalleLista(emp.getIddpl(),emp.getIdpl(), emp.getIdga(), ""+ConteoEstudiantes+". "+emp.getName(), emp.getEstatus());
            ArregloObjetos_ListView_PaseLista_DetalleLista.add(OBJ_Temporal);
            //TV5.append("" + OBJ_Temporal);
            ConteoEstudiantes++;

        }


    }



    void ConsultaDetalleLista_ConAlumno (int id_paselista) {

        List<RelDetallePaseListaAlumno> listRelDetallePaseListaAlumnos = new ArrayList<RelDetallePaseListaAlumno>();

        ArregloObjetos_ListView_PaseLista_DetalleLista = new ArrayList<PaseLista_DetalleLista>();
        String SELECT_QUERY = "SELECT * FROM DetallePaseLista where id_paselista = "+id_paselista;
        cursor2 = BaseDatos01.rawQuery(SELECT_QUERY, null);
        String[] Arreglo = cursor2.getColumnNames();
        String Condenacion="";
        String CXX1="";
        String NombreAlumnoDetallePaseLista="";
        //TV5.setText("");
        if (cursor2.getCount() != 0) {
            if (cursor2.moveToFirst()) {
                Condenacion = "";
                do {

                    String C1 = cursor2.getString(cursor2
                            .getColumnIndex("_id"));
                    int id_DetallePaseLista = ("".equals(C1.toString().trim()) ? 0 : Integer.parseInt(C1.toString().trim()));

                    String C2 = cursor2.getString(cursor2
                            .getColumnIndex("id_GrupoAlumno"));

                    int id_GrupoAlumno = ("".equals(C2.toString().trim()) ? 0 : Integer.parseInt(C2.toString().trim()));

                    String C3 = cursor2.getString(cursor2.getColumnIndex("Estatus"));
                    int Estatus = ("".equals(C3.toString().trim()) ? 0 : Integer.parseInt(C3.toString().trim()));

                    // Consultar el nombre del alumno
                    String SELECT_QUERY3 = "SELECT * FROM GrupoAlumno where _id = "+id_GrupoAlumno;
                    //tring SELECT_QUERY3 = "SELECT * FROM GrupoAlumno ";
                    Cursor cursorX = BaseDatos01.rawQuery(SELECT_QUERY3, null);
                    if (cursorX.getCount() != 0) {
                        if (cursorX.moveToFirst()) {
                            CXX1 = cursorX.getString(cursorX.getColumnIndex("id_alumno"));
                        }
                    }
                    cursorX.close();

                    String SELECT_QUERY4 = "SELECT * FROM Alumnos where _id = "+CXX1;
                    Cursor cursorY = BaseDatos01.rawQuery(SELECT_QUERY4, null);
                    if (cursorY.getCount() != 0) {
                        if (cursorY.moveToFirst()) {
                            NombreAlumnoDetallePaseLista = cursorY.getString(cursorY.getColumnIndex("nombre_alumno"));
                        }
                    }
                    cursorY.close();

                    // Original: Insertar directamente en el adaptador sin ordenar...
                    //PaseLista_DetalleLista OBJ_Temporal = new PaseLista_DetalleLista(id_DetallePaseLista,id_paselista,id_GrupoAlumno,NombreAlumnoDetallePaseLista,Estatus);
                    //ArregloObjetos_ListView_PaseLista_DetalleLista.add(OBJ_Temporal);
                    //TV5.append(""+OBJ_Temporal);

                    // Nuevos: Crear el listado, posteriormente ordenarlo e insertarlo en el adaptador

                    listRelDetallePaseListaAlumnos.add(new RelDetallePaseListaAlumno(id_DetallePaseLista,id_paselista,id_GrupoAlumno,NombreAlumnoDetallePaseLista,Estatus));




                } while (cursor2.moveToNext());
            }
        }
        // Ordenar el listado por nombre...
        Collections.sort(listRelDetallePaseListaAlumnos, new RelDetallePaseListaAlumnoChainedComparator(
                        new RelDetallePaseListaAlumnoNameComparator())
        );
        // Insertarlo en el adaptador...

        int ConteoEstudiantes=1;
        for (RelDetallePaseListaAlumno emp : listRelDetallePaseListaAlumnos) {
            //System.out.println(emp);
            PaseLista_DetalleLista OBJ_Temporal = new PaseLista_DetalleLista(emp.getIddpl(),emp.getIdpl(), emp.getIdga(), ""+ConteoEstudiantes+". "+emp.getName(), emp.getEstatus());
            ArregloObjetos_ListView_PaseLista_DetalleLista.add(OBJ_Temporal);
            //TV5.append("" + OBJ_Temporal);
            ConteoEstudiantes++;

        }



        cursor2.close();
    }

    // Temporal
    void ConsultaDetalleLista (int id_paselista) {
        //String SELECT_QUERY = "SELECT * FROM DetallePaseLista where id_paselista = "+id_paselista;
        String SELECT_QUERY = "SELECT * FROM DetallePaseLista";
        //String SELECT_QUERY = "SELECT * FROM Grupos";
        cursorZZ = BaseDatos01.rawQuery(SELECT_QUERY, null);
        if  (cursorZZ==null)
            Toast.makeText(getApplicationContext(), "Valio MADRES ", Toast.LENGTH_LONG).show();

        String[] Arreglo = cursorZZ.getColumnNames();

        //Toast.makeText(getApplicationContext(), "Columnas del Arreglo"+Arreglo.length + " Total de Registros: " + cursorZZ.getCount() +  " ["+id_paselista+"]\n", Toast.LENGTH_LONG).show();
        String Condenacion="";
        if (cursorZZ.getCount() != 0) {
            if (cursorZZ.moveToFirst()) {
                Condenacion = "";
                do {
                    for (int i = 0; i < Arreglo.length; i++)
                        Condenacion += cursorZZ.getString(i) + "#";
                    Condenacion += "\n";
                } while (cursorZZ.moveToNext());
            }
            //TV5.setText(Condenacion);

        }
        cursorZZ.close();
        //Toast.makeText(getApplicationContext(), "Resultado de Consulta DEtalle Lista \n["+id_paselista+"]\n"+Condenacion, Toast.LENGTH_LONG).show();

    }

    void ConsultarAsistencias () {
        String C1, C2, C3, C4;
        String Fin = "";
        cursorXX = BaseDatos01.rawQuery("select * from PaseLista", null);

        if (cursorXX.getCount() != 0) {
            if (cursorXX.moveToFirst()) {
                do {
                    C1 = cursorXX.getString(cursorXX
                            .getColumnIndex("_id"));

                    C2 = cursorXX.getString(cursorXX
                            .getColumnIndex("id_grupo"));


                    C3 = cursorXX.getString(cursorXX
                            .getColumnIndex("fecha_asistencia"));

                    Fin += C1 + "-" + C2 + "-" + C3 + "\n";

                } while (cursorXX.moveToNext());
            }
        }
        //TV3.setText(Fin);
        cursorXX.close();
    }

    void ConsultarGrupos () {

        ArregloObjetos_Grupos = new ArrayList<Grupo>();
        String C1, C2, C3, C4;
        String Fin = "";
        cursorGG = BaseDatos01.rawQuery("select * from " + TABLA_PRINCIPALA, null);

        if (cursorGG.getCount() != 0) {
            if (cursorGG.moveToFirst()) {
                do {
                    C1 = cursorGG.getString(cursorGG
                            .getColumnIndex("_id"));

                    C2 = cursorGG.getString(cursorGG
                            .getColumnIndex("nombre_grupo"));

                    Fin += C1 + "-" + C2 + "-" + "\n";

                    final Grupo ET1= new Grupo(
                            ("".equals(C1.toString().trim()) ? 0 : Integer.parseInt(C1.toString().trim())), // ID
                            C2); // Nombre GRUPO
                    ArregloObjetos_Grupos.add(ET1);


                } while (cursorGG.moveToNext());
            }
            //TV1.setText(Fin);
            //adapter_Grupo.notifyDataSetChanged();

        }
        cursorGG.close();
    }

    void ConsultaGrupo_Alumno_Avanzada (int id_grupo) {


        // Consulta Grupo-Alumno con Nombre de Grupo y Nombre de Alumno
        String C1, C2, C3, C4;
        String Fin = "";
        //TV2.setText(Fin);

        //String SELECT_QUERY = "SELECT * FROM Grupos t1 INNER JOIN Tutorados t2 ON t1._id = t2.id_tutor and t1._id = " + ET1.getText().toString().trim();
        Fin="";
        //String SELECT_QUERY = "SELECT * FROM Grupos t1 INNER JOIN GrupoAlumno t2 ON t1._id = t2.id_grupo and t1._id = 1";
        //String SELECT_QUERY = "SELECT * FROM Grupos t1 INNER JOIN GrupoAlumno t2 ON t1._id = t2.id_grupo and t1._id = 1 INNER JOIN Alumnos T3 on t3._id = t2.id_alumno";
        String SELECT_QUERY = "SELECT * FROM Grupos t1 INNER JOIN GrupoAlumno t2 ON t1._id = t2.id_grupo and t1._id = "+id_grupo +" INNER JOIN Alumnos T3 on t3._id = t2.id_alumno";

        //String SELECT_QUERY = "SELECT * FROM GrupoAlumno t1 INNER JOIN Grupos t2 ON t1.id_grupo = t2._id and t2._id = "+id_grupo +" INNER JOIN Alumnos T3 on t3._id = t1.id_alumno";

        //String SELECT_QUERY = "SELECT * FROM Grupos t1 INNER JOIN GrupoAlumno t2 ON t1._id = t2.id_grupo and t1._id = 1 INNER JOIN Alumnos T3 on t3._id = t2.id_alumno";

        cursorHH = BaseDatos01.rawQuery(SELECT_QUERY, null);

        String[] Arreglo = cursorHH.getColumnNames();
        String Concatenacion="";
        for (int i=0; i<Arreglo.length; i++)
            Concatenacion+=Arreglo[i]+"\n";

        //Toast.makeText(getApplicationContext(), "CHANGA TU MADRE"+cursor.getColumnCount()+"-"+Arreglo.length+Concatenacion, Toast.LENGTH_SHORT).show();





        if (cursorHH.getCount() != 0) {
            if (cursorHH.moveToFirst()) {
                do {
                    String Condenacion="";

                    for (int i=0; i<Arreglo.length; i++)
                        Condenacion+=cursorHH.getString(i)+"-";

                    // COLUMNAS
                    // ID_GRUPO  - NOMBREGRUPO - ID_GRUPO_ALUMNO - ID_GRUPO - ID_ALUMNO - ID-ALUMNO - NOMBREALUMNO

                    //C1 = cursor.getString(cursor.getColumnIndex("_id"));
                    //C1 = cursor.getString(cursor.getColumnIndex("_id")); // ID Alumno => No conviene
                    C1 = cursorHH.getString(cursorHH.getColumnIndex("id_grupo"));
                    //C1 = cursor.getString(cursor.getColumnIndex("id_GrupoAlumno"));// PROBLEMA !

                    C2 = cursorHH.getString(cursorHH.getColumnIndex("nombre_grupo"));

                    //C3 = cursor.getString(cursor
                    //       .getColumnIndex("id_grupo"));

                    C3 = cursorHH.getString(cursorHH.getColumnIndex("id_alumno"));

                    C4 = cursorHH.getString(cursorHH.getColumnIndex("nombre_alumno"));

                    //Fin += C1 + "-" + C2 + "-" + C3 + "-"+ C4 + "\n";
                    Fin += Condenacion + "\n";

                } while (cursorHH.moveToNext());
            }
            //TV2.setText(Fin);
        }
        cursorHH.close();

    }


    // Declaracion del CUSTOM ADAPTER
    private class MyCustomAdapter extends ArrayAdapter<PaseLista_DetalleLista> {
        private ArrayList<PaseLista_DetalleLista> countryList;
        Context CX;
        AdministrarGrupo AGAc;

        public MyCustomAdapter(Context context, int textViewResourceId, ArrayList<PaseLista_DetalleLista> countryList, AdministrarGrupo AGA) {
            super(context, textViewResourceId, countryList);
            AGAc = AGA;

            this.countryList = new ArrayList<PaseLista_DetalleLista>();
            this.countryList.addAll(countryList);
        }

        private class ViewHolder {
            TextView code;
            CheckBox name;
            CheckBox name2;
            Button B1;
            Button B2;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            final PaseLista_DetalleLista[] country = new PaseLista_DetalleLista[1];
            final int mposition=position;
            //final int ID_Alumno;
            ViewHolder holder = null;
            //final int[] ID_Alumno = new int[1];
            Log.v("ConvertView", String.valueOf(position));

            if (convertView == null) {
                LayoutInflater vi = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = vi.inflate(R.layout.fila_listview_administrar_grupo, null);

                holder = new ViewHolder();
                holder.code = (TextView) convertView.findViewById(R.id.code);
                holder.name = (CheckBox) convertView.findViewById(R.id.checkBox1);
                holder.name2 = (CheckBox) convertView.findViewById(R.id.checkBox2);
                holder.B1 = (Button) convertView.findViewById(R.id.administrarGrupoB1);
                holder.B2 = (Button) convertView.findViewById(R.id.administrarGrupoB2);
                convertView.setTag(holder);

                holder.name.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        CheckBox cb = (CheckBox) v;
                        PaseLista_DetalleLista country = (PaseLista_DetalleLista) cb.getTag();
                        country.setSelected(cb.isChecked());
                    }
                });

                holder.name2.setOnClickListener( new View.OnClickListener() {
                    public void onClick(View v) {
                        CheckBox cBotonSalirAChingarASuMadre = (CheckBox) v ;
                        PaseLista_DetalleLista country = (PaseLista_DetalleLista) cBotonSalirAChingarASuMadre.getTag();
                        country.setSelected2(cBotonSalirAChingarASuMadre.isChecked());
                    }
                });

                // Boton para darlo de baja...
                holder.B1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Button cBT = (Button) v;
                        PaseLista_DetalleLista country = (PaseLista_DetalleLista) cBT.getTag();
                        //String Variable=country.getName();
                        final int ID_GrupoAlumno = countryList.get(mposition).get_id_GrupoAlumno();
                        final int ID_PaseLista = countryList.get(mposition).get_id_PaseLista();
                        String Variable=countryList.get(mposition).getName();

                        Toast.makeText(AGAc, "Estudiante Seleccionado: "+Variable, Toast.LENGTH_LONG).show();

                        // Fase 1: Eliminar todos los detalles de pase de lista de ese alumno
                        BaseDatos01.delete("DetallePaseLista","id_GrupoAlumno="+ID_GrupoAlumno,null);

                        // Fase 2: Eliminar la relacion grupo-alumno
                        BaseDatos01.delete("GrupoAlumno","_id="+ID_GrupoAlumno,null);

                        finish();


                        //ContentValues valores = new ContentValues();
                        //valores.put("id_grupo","0");
                        //BaseDatos01.update("GrupoAlumno", valores, "_id=" + "" + ID_GrupoAlumno, null);


                        //Toast.makeText(AGAc, "Estudiante Seleccionado: "+Variable, Toast.LENGTH_LONG).show();
                        //finish();

                    }
                });

                // Boton para Cambiar el nombre del estudiante
                holder.B2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        final Button cBT = (Button) v;
                        country[0] = (PaseLista_DetalleLista) cBT.getTag();
                        //String Variable=country.getName();
                        String Variable=countryList.get(mposition).getName();
                        final int ID_Alumno = countryList.get(mposition).get_id();

                        AlertDialog.Builder alert = new AlertDialog.Builder(MX);
                        alert.setTitle("Cambio de Nombre de Estudiante"); //Set Alert dialog title here
                        alert.setMessage("Haga el cambio en el nombre del estudiante"); //Message here


                        // Set an EditText view to get user input
                        final EditText input = new EditText(MX);
                        Variable=Variable.replaceAll("[0-9]+", "");
                        Variable=Variable.replace(".", "");
                        Variable=Variable.trim();
                        //Variable=Variable.replaceAll(".", "");
                        input.setText(Variable);


                        alert.setView(input);

                        alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                //You will get as string input data in this variable.
                                // here we convert the input to a string and show in a toast.
                                String Nombre;
                                Nombre = input.getEditableText().toString().toUpperCase();

                                ContentValues valores = new ContentValues();
                                valores.put("nombre_alumno", Nombre);

                                //valores.put("Estatus", "" + ArregloObjetos_ListView_PaseLista_DetalleLista.get(i).get_estatus());
                                BaseDatos01.update("Alumnos", valores, "_id=" + "" + ID_Alumno, null);

                                Toast.makeText(AGAc, "Estudiante Seleccionado: "+ ID_Alumno +":"+Nombre, Toast.LENGTH_LONG).show();
                                finish();



                                //Toast.makeText(MX,srt,Toast.LENGTH_LONG).show();
                            } // End of onClick(DialogInterface dialog, int whichButton)
                        }); //End of alert.setPositiveButton
                        alert.setNegativeButton("CANCELAR", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                // NO HACER NADA !!
                                // Canceled.
                                dialog.cancel();

                            }
                        }); //End of alert.setNegativeButton


                        AlertDialog alertDialog = alert.create();
                        alertDialog.show();

                        //id = id_grupo_temporal;
                        //return id;

                    }
                });


            }
            else {
                holder = (ViewHolder) convertView.getTag();
            }


            country[0] = countryList.get(position);
            holder.code.setText(country[0].getName());
            holder.name.setChecked(country[0].isSelected());
            holder.name2.setChecked(country[0].isSelected2());

            holder.name.setTag(country[0]);
            holder.name2.setTag(country[0]);
            holder.code.setTag(country[0]);
            return convertView;
        }

    }


/*    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setTitle("Salir de Verdad?")
                .setMessage("Esta seguro de que quiere irse a chingar a su madre?")
                .setNegativeButton(android.R.string.no, null)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface arg0, int arg1) {
                        PaseLista.super.onBackPressed();

                        Context context = getApplicationContext();
                        CharSequence text = "Hello toast!";
                        int duration = Toast.LENGTH_SHORT;

                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                    }
                }).create().show();
    } */
}

