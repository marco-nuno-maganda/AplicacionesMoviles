package com.example.aplicacionpaselista_2022;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * Created by marco on 27/04/16.
 */
public class RelPaseListaPorFecha {
    private int id_Grupo;
    private int id_paselista;
    private int fecha;

    public RelPaseListaPorFecha(int IDG, int IDPL, int fec) {
        this.id_Grupo = IDG;
        this.id_paselista = IDPL;
        this.fecha = fec;
    }
    // getters and setters


    public int getIdG () { return this.id_Grupo; }
    public int getIdPL () { return this.id_paselista; }
    public int getFecha () { return this.fecha; }



    public String toString() {
        //return String.format("%d,\t%d,\t%d",id_Grupo,id_paselista,fecha);
        return String.format("Fecha: %d \tIDGRUPO: %d,\t IDPASELISTA: %d",fecha,id_Grupo,id_paselista);
    }
}

class RelPaseListaPorFechaChainedComparator implements Comparator<RelPaseListaPorFecha> {

    private List<Comparator<RelPaseListaPorFecha>> listComparators;

    @SafeVarargs
    public RelPaseListaPorFechaChainedComparator(Comparator<RelPaseListaPorFecha>... comparators) {
        this.listComparators = Arrays.asList(comparators);
    }

    @Override
    public int compare(RelPaseListaPorFecha emp1, RelPaseListaPorFecha emp2) {
        for (Comparator<RelPaseListaPorFecha> comparator : listComparators) {
            int result = comparator.compare(emp1, emp2);
            if (result != 0) {
                return result;
            }
        }
        return 0;
    }
}

class RelPaseListaPorFechaNameComparator implements Comparator<RelPaseListaPorFecha> {
    @Override
    public int compare(RelPaseListaPorFecha emp1, RelPaseListaPorFecha emp2) {
//        return emp1.getName().compareTo(emp2.getName());
        return emp1.getFecha() - emp2.getFecha(); // De menor a Mayor
    }
}

