package com.example.aplicacionpaselista_2022;

/**
 * Created by marco on 27/08/15.
 */
public class PaseLista_DetalleLista {
    private int id; // id_alumno
    private int id_PaseLista;
    private int id_GrupoAlumno;
    private String Nombre;
    private int Estatus;

    private boolean Estado1;
    private boolean Estado2;

    public PaseLista_DetalleLista (int p_id, int p_id_PaseLista, int p_id_GrupoAlumno, String p_Nombre, int p_Estatus) {
        id = p_id;
        id_PaseLista=p_id_PaseLista;
        id_GrupoAlumno=p_id_GrupoAlumno;
        Nombre = p_Nombre;
        Estatus = p_Estatus;

        switch (Estatus) {
            case 0: // Falta
                Estado1 = false; Estado2 = false;
                break;
            case 1: // Asistencia
                Estado1 = true; Estado2 = false;
                break;
            case 2: // Retardo
                Estado1 = true; Estado2 = true;
                break;
            default:
                Estado1 = false; Estado2 = false;
                break;
        }

    }

    public String toString() {
        String Cadena ="";
        int EstatusTemporal = 0;
        if ((Estado1==false)&&(Estado2==false))
            EstatusTemporal=0;

        if ((Estado1==true)&&(Estado2==false))
            EstatusTemporal=1;

        if ((Estado1==true)&&(Estado2==true))
            EstatusTemporal=2;

        //Cadena = ""+id+"**"+id_PaseLista+"**"+id_GrupoAlumno+"**"+Nombre+"**"+Estatus+":"+Estado1+":"+Estado2+"\n";
        Cadena = ""+id+"**"+id_PaseLista+"**"+id_GrupoAlumno+"**"+Nombre+"**"+EstatusTemporal+":"+Estado1+":"+Estado2+"\n";
        return Cadena;
    }

    public int get_id () {
        return id;
    }
    public int get_estatus () {
        int EstatusTemporal = 0;
        if ((Estado1==false)&&(Estado2==false))
            EstatusTemporal=0;

        if ((Estado1==true)&&(Estado2==false))
            EstatusTemporal=1;

        if ((Estado1==true)&&(Estado2==true))
            EstatusTemporal=2;

        return Estatus;
    }

    private void ActualizaEstado () {
        if ((Estado1==false)&&(Estado2==false))
            Estatus=0;

        if ((Estado1==true)&&(Estado2==false))
            Estatus=1;

        if ((Estado1==true)&&(Estado2==true))
            Estatus=2;

    }

    public int get_id_PaseLista () {
        return id_PaseLista;
    }

    public int get_id_GrupoAlumno () {
        return id_GrupoAlumno;
    }

/*    public void set id () {
        return id;
    }
    public int get_estatus () {
        return Estatus;
    }

    public int get_id_PaseLista () {
        return id_PaseLista;
    }  */

    public void setSelected (boolean Ent) {
        Estado1= Ent;
        ActualizaEstado();
    }

    public void setSelected2 (boolean Ent) {
        Estado2= Ent;
        ActualizaEstado();
    }

    public void setName (String Name) {
        Nombre = Name;
    }

    public boolean isSelected () {
        return Estado1;
    }

    public boolean isSelected2 () {
        return Estado2;
    }

    public String getName () {
        return Nombre;
    }

    public String Asistencia () {
        if (Estado1)
            if (Estado2)
                return ("(R)");
            else
                return ("(A)");
        else
            return ("(F)");

    }



}

