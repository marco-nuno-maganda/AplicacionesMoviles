package com.example.aplicacionpaselista_2022;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by marco on 26/06/15.
 */
public class BaseDatosGAA extends SQLiteOpenHelper {

    String sqlCreate1  = "CREATE TABLE Grupos           (_id INTEGER PRIMARY KEY, nombre_grupo TEXT)";
    String sqlCreate2  = "CREATE TABLE Alumnos          (_id INTEGER PRIMARY KEY, nombre_alumno TEXT)";
    String sqlCreate3  = "CREATE TABLE GrupoAlumno      (_id INTEGER PRIMARY KEY, id_grupo REFERENCES Grupos(_id), id_alumno REFERENCES Alumnos(_id))";
    String sqlCreate4  = "CREATE TABLE PaseLista        (_id INTEGER PRIMARY KEY, id_grupo REFERENCES Grupos(_id), fecha_asistencia INTEGER)";
    String sqlCreate5  = "CREATE TABLE DetallePaseLista (_id INTEGER PRIMARY KEY, id_paselista REFERENCES PaseLista(_id), id_GrupoAlumno REFERENCES GrupoAlumno(_id), Estatus INTEGER)";

    public BaseDatosGAA(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);

    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(sqlCreate1);
        db.execSQL(sqlCreate2);
        db.execSQL(sqlCreate3);
        db.execSQL(sqlCreate4);
        db.execSQL(sqlCreate5);

    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            // Enable foreign key constraints
            db.execSQL("PRAGMA foreign_keys=ON;");
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        //eliminamos la version anterior de la tabla
        db.execSQL("DROP TABLE IF EXISTS Grupos");
        db.execSQL("DROP TABLE IF EXISTS Alumnos");
        db.execSQL("DROP TABLE IF EXISTS GrupoAlumno");
        db.execSQL("DROP TABLE IF EXISTS PaseLista");
        db.execSQL("DROP TABLE IF EXISTS DetallePaseLista");

        //aqu� creamos la nueva versi�n de la tabla
        db.execSQL(sqlCreate1);
        db.execSQL(sqlCreate2);
        db.execSQL(sqlCreate3);
        db.execSQL(sqlCreate4);
        db.execSQL(sqlCreate5);

    }
}
