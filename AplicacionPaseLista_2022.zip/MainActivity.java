package com.example.aplicacionpaselista_2022;


/*
Contraseña del reposito: mentada de madre
Paso 1: Seleccionar Build => Generate Signed APK
Paso 2: Al APK Generado del paso anterior, aplicarle el Script "AlinearAplicacion.sh" =>
Ese APK se carga en el Google Play
 */

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.format.Time;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TabHost;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {

    Button BotonAgregarAlumno, BotonPaseLista, BotonCrearGrupoDeArchivoTexto, BotonFechaHOY, BotonAnalizarDatosLista, BotonFinalizarAplicacion, BotonCrearGrupoVacio, BotonAdministrarGrupos;

    TextView TVResGrupo,TV1, TV3, TV4, TV5, TV6, TV_FechaSeleccionada, T4_0, T4_1, T4_2, T4_3, T4_4, T4_5, T4_6, T4_7, T4_8, tvIdGrupoPestanaAnalisis, tvNombreGrupoPestanaAnalisis;

    Spinner SP1, SP2, SP3, SP4;

    DatePicker dp;
    DatePicker.OnDateChangedListener Listener01;
    Time today;
    int Dia;
    int Mes;
    int Anno;

    // Objetos de Base de DAtos
    final String NOMBRE_BASE_DATOS = "Basedatos001.db";
    final String TABLA_PRINCIPALA = "Grupos";
    final String TABLA_PRINCIPALB = "Alumnos";
    final String TABLA_SECUNDARIA = "GrupoAlumno";
    BaseDatosGAA ObjetoBaseDatosGAA;
    SQLiteDatabase BaseDatos01;
    Cursor cursor;

    // Contexto
    Context CX;
    MainActivity MX;

    // Adaptadores
    AdaptadorGrupo adapter_Grupo;
    AdaptadorEstudiante adapter_Estudiante;
    AdaptadorEstudiante adapter_Estudiante2;

    // Arreglos Objetos
    public ArrayList<Grupo> ArregloObjetos_Grupos;
    public ArrayList<Estudiante> ArregloObjetos_Estudiantes; //= new ArrayList<Grupo>();
    public List<RelNombreAlumno_GA> listRelNombreAlumno_GAs;// = new ArrayList<RelNombreAlumno_GA>();
    public List<RelNombreAlumno_GA> listRelNombreAlumno_GAs_2;// = new ArrayList<RelNombreAlumno_GA>();

    long id_grupo_temporal;

    AlertDialog.Builder dlgAlert ;
    TableLayout stk;// = (TableLayout) findViewById(R.id.table_main);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_main);



        stk = (TableLayout) findViewById(R.id.table_main);


        // Inicializacion Variables
        id_grupo_temporal=0;
        dlgAlert  = new AlertDialog.Builder(this);

        listRelNombreAlumno_GAs   = new ArrayList<RelNombreAlumno_GA>();
        listRelNombreAlumno_GAs_2 = new ArrayList<RelNombreAlumno_GA>();

        // Manejo de la BAse de datos
        String ArchivoDB = NOMBRE_BASE_DATOS;
        // Guarda el archivo de labase de datos en el directorio RAIZ (o cualquier ruta de usuario)
        //String ArchivoDB = Environment.getExternalStorageDirectory().getAbsolutePath()+"/"+NOMBRE_BASE_DATOS;
        ObjetoBaseDatosGAA = new BaseDatosGAA(this, ArchivoDB, null, 1);
        BaseDatos01 = ObjetoBaseDatosGAA.getWritableDatabase();

        // Contexto
        CX = getApplicationContext();
        MX = this;

        // Agregar las pestañas---
        Resources res = getResources();
        TabHost tabHost = (TabHost) findViewById(R.id.tabhost);
        tabHost.setup();

        TabHost.TabSpec spec1 = tabHost.newTabSpec("");
        spec1.setContent(R.id.tab1);
        spec1.setIndicator("PASES LISTA");

        TabHost.TabSpec spec2 = tabHost.newTabSpec("");
        spec2.setContent(R.id.tab3);
        spec2.setIndicator("Grupos");

        TabHost.TabSpec spec3 = tabHost.newTabSpec("");
        spec3.setContent(R.id.tab2);
        spec3.setIndicator("Alumnos");
        //spec3.setIndicator("",getResources().getDrawable(R.mipmap.ic_launcher));

        TabHost.TabSpec spec4 = tabHost.newTabSpec("");
        spec4.setContent(R.id.tab4);
        spec4.setIndicator("Estadisticas");

        tabHost.addTab(spec1);
        tabHost.addTab(spec2);
        tabHost.addTab(spec3);
        tabHost.addTab(spec4);


        // Asignar IDs a Objetos
        BotonPaseLista = (Button) findViewById(R.id.button1_0);
        BotonFechaHOY = (Button) findViewById(R.id.button_hoy);
        BotonCrearGrupoVacio = (Button) findViewById(R.id.button1);
        BotonFinalizarAplicacion = (Button) findViewById(R.id.button_salir_aplicacion);
        BotonCrearGrupoDeArchivoTexto = (Button) findViewById(R.id.button1_CGA);
        BotonAgregarAlumno = (Button) findViewById(R.id.button2);
        BotonAnalizarDatosLista= (Button) findViewById(R.id.button1_2);
        BotonAdministrarGrupos = (Button) findViewById(R.id.buttonAdministrarGrupo);

        TVResGrupo = (TextView) findViewById(R.id.ResumenGrupo);
        T4_1 = (TextView) findViewById(R.id.textViewT4_1);
        T4_3 = (TextView) findViewById(R.id.textViewT4_3);
        T4_8 = (TextView) findViewById(R.id.textViewT4_8);
        tvIdGrupoPestanaAnalisis=  (TextView) findViewById(R.id.id_Grupo_PestanaAnalisis);
        tvNombreGrupoPestanaAnalisis=  (TextView) findViewById(R.id.Nombre_Grupo_PestanaAnalisis);

        TV_FechaSeleccionada = (TextView) findViewById(R.id.textViewT1_0);
        dp = (DatePicker) findViewById(R.id.datePicker3);


        SP1 = (Spinner) findViewById(R.id.spinner1);
        SP2 = (Spinner) findViewById(R.id.spinner2);
        SP3 = (Spinner) findViewById(R.id.spinner3);
        SP4 = (Spinner) findViewById(R.id.spinner4);
        ArregloObjetos_Grupos = new ArrayList<Grupo>();
        ConsultarGrupos();
        adapter_Grupo = new AdaptadorGrupo(MX, R.layout.fila_spinner_personal, ArregloObjetos_Grupos);
        adapter_Grupo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        SP1.setAdapter(adapter_Grupo);
        SP1.setSelection(0);

        ArregloObjetos_Estudiantes = new ArrayList<Estudiante>();
        ActualizarSpinnerAlumnos();


/*        adapter_Estudiante2 = new AdaptadorEstudiante(MX, R.layout.fila_spinner_estudiante, ArregloObjetos_Estudiantes);
        adapter_Estudiante2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        SP3.setAdapter(adapter_Estudiante2);
        SP3.setSelection(0); */


        SP4.setAdapter(adapter_Grupo);
        SP4.setSelection(0);



        // Obtener la Fecha del Dispositivo
        today = new Time(Time.getCurrentTimezone());
        today.setToNow();
        Dia = today.monthDay;
        Mes = today.month + 1;
        Anno = today.year;
        String Cadena = Dia + "/" + Mes + "/" + Anno;
        TV_FechaSeleccionada.setText(Cadena);        

        // Originalmente lanza la captura de la asistencia del dia especificado
        BotonPaseLista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getBaseContext(), "Primera Opcion",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, PaseLista.class);
                intent.putExtra("Dia", Dia);
                intent.putExtra("Mes", Mes);
                intent.putExtra("Anno", Anno);
                //startActivity(intent);
                startActivityForResult(intent, 2);
            }
        });

        BotonAdministrarGrupos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AdministrarGrupo.class);
                intent.putExtra("Dia", Dia);
                intent.putExtra("Mes", Mes);
                intent.putExtra("Anno", Anno);
                //startActivity(intent);
                startActivityForResult(intent, 3);
            }
        });

        // Reconfigura el calendario para la fecha de HOY
        BotonFechaHOY.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dp.init(today.year, today.month, today.monthDay, Listener01);
                today.setToNow();
                Dia = today.monthDay;
                Mes = today.month + 1;
                Anno = today.year;
                String Cadena = Dia + "/" + Mes + "/" + Anno;
                TV_FechaSeleccionada.setText(Cadena);
                BotonFechaHOY.setEnabled(false);


            }
        });

        BotonFinalizarAplicacion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        // Agregar Grupo
        BotonCrearGrupoVacio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InsertarVacioGrupo();
            }
        });

        // Agregar Alumno
        BotonAgregarAlumno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Insertar el Alumno

                //InsertaEstudiante(ET2.getText().toString());
                InsertaAlumnoEnGrupo();


            }
        });


        // Seleccionar Archivo con Nombre de Alumnos/Grupo
        BotonCrearGrupoDeArchivoTexto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse(Environment.getExternalStorageDirectory().getPath());

                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setDataAndType(uri, "plain/text");

                String chooserName = "Seleccionar Archivo";
                Intent chooser = Intent.createChooser(intent, chooserName);

                Toast.makeText(getApplicationContext(),"Puto",Toast.LENGTH_SHORT).show();

                startActivityForResult(chooser, 1);


            }
        });


        // Continuo monitoreo al control calentario para actualizar la fecha del TextView
        Listener01 = new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker arg0, int arg1, int arg2, int arg3) {
                // TODO Auto-generated method stub

                Dia = arg3;
                Mes = arg2 + 1;
                Anno = arg1;
                String Cadena = Dia + "/" + Mes + "/" + Anno;
                TV_FechaSeleccionada.setText(Cadena);
                BotonFechaHOY.setEnabled(true);
            }
        };
        dp.init(dp.getYear(), dp.getMonth(), dp.getDayOfMonth(), Listener01);



        // Lanza el Analizador de Datos
/*        BotonAnalizarDatosLista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ActualizaEstadistica();

            }
        });*/


        // Seleccion del Grupo
        SP1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View v, int position, long id) {

                String Nombre_Grupo = ((TextView) v.findViewById(R.id.tv_nombre)).getText().toString();
                String ID_Grupo = ((TextView) v.findViewById(R.id.tv_apellido)).getText().toString();
                ActualizarInformacionGrupoInterfaz(Nombre_Grupo, ID_Grupo);


                //Toast.makeText(getApplicationContext(), "Seleccion del Spiner2-\nElemento [ " + position + "] Nombre: " + Nombre_Grupo + " Apellidos: " + ID_Grupo, Toast.LENGTH_LONG).show();

//                T4_1.setText(ID_Grupo);
//                T4_3.setText(Nombre_Grupo);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });

        SP1.setOnTouchListener(new Spinner.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getAction();
                switch (action) {
                    case MotionEvent.ACTION_DOWN:
                        v.getParent().requestDisallowInterceptTouchEvent(true);
                        break;
                    case MotionEvent.ACTION_UP:
                        v.getParent().requestDisallowInterceptTouchEvent(false);
                        break;

                }
                v.onTouchEvent(event);
                return true;
            }
        });


        // Seleccion del Grupo
        SP4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View v, int position, long id) {

                String Nombre_Grupo = ((TextView) v.findViewById(R.id.tv_nombre)).getText().toString();
                String ID_Grupo = ((TextView) v.findViewById(R.id.tv_apellido)).getText().toString();
                //ActualizarInformacionGrupoInterfaz(Nombre_Grupo, ID_Grupo);

                tvIdGrupoPestanaAnalisis.setText(ID_Grupo);
                tvNombreGrupoPestanaAnalisis.setText(Nombre_Grupo);

                ActualizaEstadistica();



                //Toast.makeText(getApplicationContext(), "Seleccion del Spiner2-\nElemento [ " + position + "] Nombre: " + Nombre_Grupo + " Apellidos: " + ID_Grupo, Toast.LENGTH_LONG).show();

//                T4_1.setText(ID_Grupo);
//                T4_3.setText(Nombre_Grupo);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });

        SP4.setOnTouchListener(new Spinner.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getAction();
                switch (action) {
                    case MotionEvent.ACTION_DOWN:
                        v.getParent().requestDisallowInterceptTouchEvent(true);
                        break;
                    case MotionEvent.ACTION_UP:
                        v.getParent().requestDisallowInterceptTouchEvent(false);
                        break;

                }
                v.onTouchEvent(event);
                return true;
            }
        });

        // Permisos
        if (Build.VERSION.SDK_INT >= 23) {
            int REQUEST_CODE_PERMISSION_STORAGE = 100;
            String[] permissions = {
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
            };

            for (String str : permissions) {
                if (this.checkSelfPermission(str) != PackageManager.PERMISSION_GRANTED) {
                    this.requestPermissions(permissions, REQUEST_CODE_PERMISSION_STORAGE);
                    return;
                }
            }
        }

    }

    void ActualizarSpinnerAlumnos () {
        ConsultarAlumnos();
        adapter_Estudiante = new AdaptadorEstudiante(MX, R.layout.fila_spinner_estudiante, ArregloObjetos_Estudiantes);
        adapter_Estudiante.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        SP2.setAdapter(adapter_Estudiante);
        SP2.setSelection(0);
    }

    @Override
    public void onBackPressed() {
        finish();
    }

/*
  // Version Anterior...

    public void ActualizaEstadistica () {
        List<RelPaseListaPorFecha> listRelPaseListaPorFechas = new ArrayList<RelPaseListaPorFecha>();

        String IdGrupo=tvIdGrupoPestanaAnalisis.getText().toString();

        int ID=("".equals(IdGrupo.toString().trim()) ? 0 : Integer.parseInt(IdGrupo.toString().trim()));

        if  (ID == 0 ){ // No hace nada...
            return;
        }


        String Fin = "";
        Cursor cursorXX;


        //void ConsultarAsistencias () {
        String C1, C2, C3, C4;

        //cursorXX = BaseDatos01.rawQuery("select * from PaseLista where id_grupo = 1", null);
        cursorXX = BaseDatos01.rawQuery("select * from PaseLista where id_grupo = " + tvIdGrupoPestanaAnalisis.getText().toString().trim(), null);


        if (cursorXX.getCount() != 0) {
            if (cursorXX.moveToFirst()) {
                do {
                    C1 = cursorXX.getString(cursorXX
                            .getColumnIndex("_id"));
                    C2 = cursorXX.getString(cursorXX
                            .getColumnIndex("id_grupo"));

                    C3 = cursorXX.getString(cursorXX
                            .getColumnIndex("fecha_asistencia"));


                    //Fin += C1 + "-" + C2 + "-" + C3 + "\n";

                    int id_grupo     = ("".equals(C2.toString().trim()) ? 0 : Integer.parseInt(C2.toString().trim()));
                    int Id_Paselista = ("".equals(C1.toString().trim()) ? 0 : Integer.parseInt(C1.toString().trim()));
                    int fecha        = ("".equals(C3.toString().trim()) ? 0 : Integer.parseInt(C3.toString().trim()));

                    listRelPaseListaPorFechas.add(new RelPaseListaPorFecha(id_grupo,Id_Paselista,fecha));

                } while (cursorXX.moveToNext());
            }
        }
        //TV3.setText(Fin);
        cursorXX.close();

        // Ordenar las fechas iniciando por las más antiguar (o al reves...)

        Collections.sort(listRelPaseListaPorFechas, new RelPaseListaPorFechaChainedComparator(
                        new RelPaseListaPorFechaNameComparator())
        );


        int [] [] scores = new int[0][]; // = new int [ 4 ] [ listRelPaseListaPorFechas.size() ] ;

        int ContadorIteraciones=0;
        int ConteoAsistenciasPaseLista=0;

        String T="";
        for (RelPaseListaPorFecha emp : listRelPaseListaPorFechas) {
            int AsistenciasxDia=0;
            int RetardosxDia=0;

            //Fin+=emp.toString()+"\n";
            //Fin+=emp.getFecha()+"\n";
            T = ConsultaDetalleLista_ConAlumno(emp.getIdPL());
            if (ContadorIteraciones==0) { // Consultar Nombres y Estatuses
                scores = new int [listRelNombreAlumno_GAs.size()][listRelPaseListaPorFechas.size()];
            }
            Collections.sort(listRelNombreAlumno_GAs, new RelNombreAlumno_GAChainedComparator(
                            new RelNombreAlumno_GANameComparator())
            );
            ConteoAsistenciasPaseLista=0;
            for (RelNombreAlumno_GA empX : listRelNombreAlumno_GAs) {
                //T+="\t"+empX.toString()+"\n";
                scores[ConteoAsistenciasPaseLista][ContadorIteraciones]=empX.getEStatus();
                switch (empX.getEStatus()) {case 1: AsistenciasxDia++; break; case 2: RetardosxDia++; break;default: break;}
                ConteoAsistenciasPaseLista++;
            }
            Fin+=emp.getFecha()+"- A: "+AsistenciasxDia+" R: "+RetardosxDia+" TA: "+listRelNombreAlumno_GAs.size()+"\n";
            Fin+="\t"+T;
            ContadorIteraciones++;
        }
        int i,j;

        T="\n";
        int SumaRetardos=0;
        int SumaAsistencias=0;

        for (i=0; i<listRelNombreAlumno_GAs.size(); i++) {
            T+=listRelNombreAlumno_GAs.get(i).getName()+" ";
            SumaRetardos=0;
            SumaAsistencias=0;
            for (j = 0; j < listRelPaseListaPorFechas.size(); j++) {
                //T+=""+scores[i][j]+" ";
                T+=""+Estatus_Asistencia(scores[i][j])+" ";
                switch (scores[i][j]) {
                    case 1: SumaAsistencias++; break;
                    case 2: SumaRetardos++; break;
                    default: break;
                }
            }
            T+= "Total: "+SumaAsistencias+"/"+SumaRetardos+"/"+listRelPaseListaPorFechas.size();
            T+="\n";
        }
        Fin+=T;


        stk.removeAllViews();
        LinearLayout.LayoutParams params;

        TableRow tbrow0 = new TableRow(this);
        TableRow tbrow = new TableRow(this);


        TextView tv0; // TRUCOSO  - Agregar COLUMNA EN BLANCO
        TextView tv1; // TRUCOSO  - Agregar COLUMNA EN BLANCO


        // Agregar Primera Columna de Alumnos..
        tv0 = new TextView(this);
        tv0.setText(" Nombre del Alumno");
        tv0.setTextColor(Color.BLACK);
        tv0.setGravity(Gravity.CENTER);
        tbrow0.addView(tv0);

        // Agregar la Columna de Asistencas
        tv0 = new TextView(this);
        tv0.setText(" Asistencias ");
        tv0.setTextColor(Color.GREEN);
        tbrow0.addView(tv0);

        // Agregar Columna de Retardos
        tv0 = new TextView(this);
        tv0.setText(" Retardos ");
        tv0.setTextColor(Color.YELLOW);
        tbrow0.addView(tv0);

        // Agregar Columna de Faltas
        tv0 = new TextView(this);
        tv0.setText(" Faltas ");
        tv0.setGravity(Gravity.CENTER);
        tv0.setTextColor(Color.RED);
        tbrow0.addView(tv0);

        // Agregar Columna Total de Clases
        tv0 = new TextView(this);
        tv0.setText(" Total de Clases ");
        tv0.setGravity(Gravity.CENTER);
        tv0.setTextColor(Color.BLACK);
        tbrow0.addView(tv0);

        // Agregar la N columnas de los pases de lista
        for (RelPaseListaPorFecha emp : listRelPaseListaPorFechas) {
            tv0 = new TextView(this);
            tv0.setText("      "+emp.getFecha()+"      ");
            tv0.setTextColor(Color.MAGENTA);
            tv0.setGravity(Gravity.CENTER);
            tbrow0.addView(tv0);

        }




        stk.addView(tbrow0);

        for (i = 0; i < listRelNombreAlumno_GAs.size(); i++) {

            tbrow = new TableRow(this);
            // Primera Columna "Vacia"
            //tv1 = new TextView(this);
            //Cadena="";
            //tv1.setText(Cadena);
            //tv1.setTextColor(Color.GREEN);
            //tbrow.addView(tv1);

            // Columna del Nombre ..
            tv1 = new TextView(this);
            tv1.setText(listRelNombreAlumno_GAs.get(i).getName() + "     ");
            tv1.setTextColor(Color.GREEN);
            tbrow.addView(tv1);

            int SumaFaltas=0;
            SumaRetardos=0;
            SumaAsistencias=0;
            for (j = 0; j < listRelPaseListaPorFechas.size(); j++) {
                //T+=""+scores[i][j]+" ";
                //T+=""+Estatus_Asistencia(scores[i][j])+" ";
                switch (scores[i][j]) {
                    case 0: SumaFaltas++; break;
                    case 1: SumaAsistencias++; break;
                    case 2: SumaRetardos++; break;
                    default: break;
                }
            }
            //T+= "Total:

            // Resumen

            // Agregar la Columna de Asistencas
            tv1 = new TextView(this);
            tv1.setText(""+SumaAsistencias);
            tv1.setTextColor(Color.GREEN);
            tv1.setGravity(Gravity.CENTER);
            tbrow.addView(tv1);

            // Agregar Columna de Retardos
            tv1 = new TextView(this);
            tv1.setText(""+SumaRetardos);
            tv1.setTextColor(Color.YELLOW);
            tv1.setGravity(Gravity.CENTER);
            tbrow.addView(tv1);

            // Agregar Columna de Faltas
            tv1 = new TextView(this);
            tv1.setText(""+SumaFaltas);
            tv1.setTextColor(Color.RED);
            tv1.setGravity(Gravity.CENTER);
            tbrow.addView(tv1);

            // Agregar Columna Total de Clases
            tv1 = new TextView(this);
            tv1.setText(""+listRelPaseListaPorFechas.size());
            tv1.setTextColor(Color.BLACK);
            tv1.setGravity(Gravity.CENTER);
            tbrow.addView(tv1);

            // Las N Columnas de los pases de Lista (Desglose)

            for (j = 0; j < listRelPaseListaPorFechas.size(); j++) {
                //T=""+j;
                //T+=""+scores[i][j]+" ";
                T=Estatus_Asistencia(scores[i][j]);
                tv1 = new TextView(this);
                tv1.setText(T);
                tv1.setTextColor(Color.RED);
                tv1.setGravity(Gravity.CENTER);
                tbrow.addView(tv1);

            }


            stk.addView(tbrow);
        }
    }
*/


    // Version Nueva...

    public void ActualizaEstadistica () {
        List<RelPaseListaPorFecha> listRelPaseListaPorFechas = new ArrayList<RelPaseListaPorFecha>();

        String IdGrupo=tvIdGrupoPestanaAnalisis.getText().toString();

        int ID=("".equals(IdGrupo.toString().trim()) ? 0 : Integer.parseInt(IdGrupo.toString().trim()));

        if  (ID == 0 ){ // No hace nada...
            return;
        }


        String Fin = "";
        Cursor cursorXX;


        //void ConsultarAsistencias () {
        String C1, C2, C3, C4;

        //cursorXX = BaseDatos01.rawQuery("select * from PaseLista where id_grupo = 1", null);
        cursorXX = BaseDatos01.rawQuery("select * from PaseLista where id_grupo = " + tvIdGrupoPestanaAnalisis.getText().toString().trim(), null);


        if (cursorXX.getCount() != 0) {
            if (cursorXX.moveToFirst()) {
                do {
                    C1 = cursorXX.getString(cursorXX.getColumnIndex("_id"));
                    C2 = cursorXX.getString(cursorXX.getColumnIndex("id_grupo"));
                    C3 = cursorXX.getString(cursorXX.getColumnIndex("fecha_asistencia"));


                    //Fin += C1 + "-" + C2 + "-" + C3 + "\n";

                    int id_grupo     = ("".equals(C2.toString().trim()) ? 0 : Integer.parseInt(C2.toString().trim()));
                    int Id_Paselista = ("".equals(C1.toString().trim()) ? 0 : Integer.parseInt(C1.toString().trim()));
                    int fecha        = ("".equals(C3.toString().trim()) ? 0 : Integer.parseInt(C3.toString().trim()));

                    listRelPaseListaPorFechas.add(new RelPaseListaPorFecha(id_grupo,Id_Paselista,fecha));

                } while (cursorXX.moveToNext());
            }
        }
        //TV3.setText(Fin);
        cursorXX.close();

        // Ordenar las fechas iniciando por las más antiguar (o al reves...)

        Collections.sort(listRelPaseListaPorFechas, new RelPaseListaPorFechaChainedComparator(
                        new RelPaseListaPorFechaNameComparator())
        );


        int [] [] scores = new int[0][]; // = new int [ 4 ] [ listRelPaseListaPorFechas.size() ] ;

        int ContadorIteraciones=0;
        int ConteoAsistenciasPaseLista=0;

        String T="";
        for (RelPaseListaPorFecha emp : listRelPaseListaPorFechas) {
            int AsistenciasxDia=0;
            int RetardosxDia=0;

            //Fin+=emp.toString()+"\n";
            //Fin+=emp.getFecha()+"\n";
            T = ConsultaDetalleLista_ConAlumno(emp.getIdPL());
            if (ContadorIteraciones==0) { // Consultar Nombres y Estatuses
                scores = new int [listRelNombreAlumno_GAs.size()][listRelPaseListaPorFechas.size()];
            }
            Collections.sort(listRelNombreAlumno_GAs, new RelNombreAlumno_GAChainedComparator(
                            new RelNombreAlumno_GANameComparator())
            );
            ConteoAsistenciasPaseLista=0;
            for (RelNombreAlumno_GA empX : listRelNombreAlumno_GAs) {
                //T+="\t"+empX.toString()+"\n";
                scores[ConteoAsistenciasPaseLista][ContadorIteraciones]=empX.getEStatus();
                switch (empX.getEStatus()) {case 1: AsistenciasxDia++; break; case 2: RetardosxDia++; break;default: break;}
                ConteoAsistenciasPaseLista++;
            }
            Fin+=emp.getFecha()+"- A: "+AsistenciasxDia+" R: "+RetardosxDia+" TA: "+listRelNombreAlumno_GAs.size()+"\n";
            Fin+="\t"+T;
            ContadorIteraciones++;
        }
        int i,j;

        T="\n";
        int SumaRetardos=0;
        int SumaAsistencias=0;

        for (i=0; i<listRelNombreAlumno_GAs.size(); i++) {
            T+=listRelNombreAlumno_GAs.get(i).getName()+" ";
            SumaRetardos=0;
            SumaAsistencias=0;
            for (j = 0; j < listRelPaseListaPorFechas.size(); j++) {
                //T+=""+scores[i][j]+" ";
                T+=""+Estatus_Asistencia(scores[i][j])+" ";
                switch (scores[i][j]) {
                    case 1: SumaAsistencias++; break;
                    case 2: SumaRetardos++; break;
                    default: break;
                }
            }
            T+= "Total: "+SumaAsistencias+"/"+SumaRetardos+"/"+listRelPaseListaPorFechas.size();
            T+="\n";
        }
        Fin+=T;


        stk.removeAllViews();
        LinearLayout.LayoutParams params;

        TableRow tbrow0 = new TableRow(this);
        TableRow tbrow = new TableRow(this);


        TextView tv0; // TRUCOSO  - Agregar COLUMNA EN BLANCO
        TextView tv1; // TRUCOSO  - Agregar COLUMNA EN BLANCO

        tv0 = new TextView(this);
        tv0.setText("#");
        tv0.setTextColor(Color.BLACK);
        tv0.setGravity(Gravity.CENTER);
        tbrow0.addView(tv0);


        // Agregar Primera Columna de Alumnos..
        tv0 = new TextView(this);
        tv0.setText(" Nombre del Alumno");
        tv0.setTextColor(Color.BLACK);
        tv0.setGravity(Gravity.CENTER);
        tbrow0.addView(tv0);

        // Agregar la Columna de Asistencas
        tv0 = new TextView(this);
        tv0.setText(" Asistencias ");
        tv0.setTextColor(Color.GREEN);
        tbrow0.addView(tv0);

        // Agregar Columna de Retardos
        tv0 = new TextView(this);
        tv0.setText(" Retardos ");
        tv0.setTextColor(Color.YELLOW);
        tbrow0.addView(tv0);

        // Agregar Columna de Faltas
        tv0 = new TextView(this);
        tv0.setText(" Faltas ");
        tv0.setGravity(Gravity.CENTER);
        tv0.setTextColor(Color.RED);
        tbrow0.addView(tv0);

        // Agregar Columna Total de Clases
        tv0 = new TextView(this);
        tv0.setText(" Total de Clases ");
        tv0.setGravity(Gravity.CENTER);
        tv0.setTextColor(Color.BLACK);
        tbrow0.addView(tv0);

        // Agregar la N columnas de los pases de lista
        for (RelPaseListaPorFecha emp : listRelPaseListaPorFechas) {
            tv0 = new TextView(this);
            tv0.setText("      "+emp.getFecha()+"      ");
            tv0.setTextColor(Color.MAGENTA);
            tv0.setGravity(Gravity.CENTER);
            tbrow0.addView(tv0);

        }




        stk.addView(tbrow0);
        int AlumnosRecordNegativo=0;

        for (i = 0; i < listRelNombreAlumno_GAs.size(); i++) {

            tbrow = new TableRow(this);
            // Primera Columna "Vacia"
            tv1 = new TextView(this);
            tv1.setText(""+(i+1)+". ");
            tv1.setTextColor(Color.MAGENTA);
            tbrow.addView(tv1);

            // Columna del Nombre ..
            tv1 = new TextView(this);
            tv1.setText(listRelNombreAlumno_GAs.get(i).getName() + "     ");
            tv1.setTextColor(Color.GREEN);
            tbrow.addView(tv1);

            int SumaFaltas=0;
            SumaRetardos=0;
            SumaAsistencias=0;
            for (j = 0; j < listRelPaseListaPorFechas.size(); j++) {
                //T+=""+scores[i][j]+" ";
                //T+=""+Estatus_Asistencia(scores[i][j])+" ";
                switch (scores[i][j]) {
                    case 0: SumaFaltas++; break;
                    case 1: SumaAsistencias++; break;
                    case 2: SumaRetardos++; break;
                    default: break;
                }
            }
            //T+= "Total:

            // Resumen

            // Agregar la Columna de Asistencas
            tv1 = new TextView(this);
            float PorcentajeA = (float) 100.0*((float) SumaAsistencias)/((float) listRelPaseListaPorFechas.size());
            float PorcentajeB = (float) 100.0*((float) SumaFaltas)/((float) listRelPaseListaPorFechas.size());


            //tv1.setText(""+SumaAsistencias+" ("+(100*(SumaAsistencias/listRelPaseListaPorFechas.size()))+"%)");
            tv1.setText("" + SumaAsistencias + "\n(" + PorcentajeA + "%)");
            if (PorcentajeA > 70.0)
                tv1.setTextColor(Color.GREEN);
            else {
                tv1.setTextColor(Color.RED);
                AlumnosRecordNegativo++;
            }
            tv1.setGravity(Gravity.CENTER);
            tbrow.addView(tv1);

            // Agregar Columna de Retardos
            tv1 = new TextView(this);
            tv1.setText("" + SumaRetardos);
            if (PorcentajeA > 70.0)
                tv1.setTextColor(Color.GREEN);
            else
                tv1.setTextColor(Color.RED);
            tv1.setGravity(Gravity.CENTER);
            tbrow.addView(tv1);

            // Agregar Columna de Faltas
            tv1 = new TextView(this);
            tv1.setText("" + SumaFaltas + "\n(" + PorcentajeB + "%)");
            if (PorcentajeA > 70.0)
                tv1.setTextColor(Color.GREEN);
            else
                tv1.setTextColor(Color.RED);
            tv1.setGravity(Gravity.CENTER);
            tbrow.addView(tv1);

            // Agregar Columna Total de Clases
            tv1 = new TextView(this);
            tv1.setText(""+listRelPaseListaPorFechas.size());
            tv1.setTextColor(Color.BLACK);
            tv1.setGravity(Gravity.CENTER);
            tbrow.addView(tv1);

            // Las N Columnas de los pases de Lista (Desglose)

            for (j = 0; j < listRelPaseListaPorFechas.size(); j++) {
                //T=""+j;
                //T+=""+scores[i][j]+" ";
                T=Estatus_Asistencia(scores[i][j]);
                tv1 = new TextView(this);
                tv1.setText(T);
                tv1.setTextColor(Color.RED);
                tv1.setGravity(Gravity.CENTER);
                tbrow.addView(tv1);

            }


            stk.addView(tbrow);


        }

        String Cad="";
        float PorcentajeMal=(float)100*((float)AlumnosRecordNegativo/ (float)listRelNombreAlumno_GAs.size());
        Cad+=   "Resumen de Grupo: \n"+
                "Total de Alumnos: "+listRelNombreAlumno_GAs.size()+"\n"+
                "Fechas de Pases de Lista: "+listRelPaseListaPorFechas.size()+"\n"+
                "Total de Alumnos con menos del 75% de Asistencia: "+AlumnosRecordNegativo+" ("+PorcentajeMal+"%)\n";
        TVResGrupo.setText(Cad);
    }

    String Estatus_Asistencia (int Valor) {
        String V="X";
        switch (Valor) {
            case 0:  V="F"; break;
            case 1:  V="A"; break;
            case 2:  V="R"; break;
            default: V="X"; break;
        }
        return V;
    }


    String ConsultaDetalleLista_ConAlumno (int id_paselista) {
        Cursor cursor2;

        listRelNombreAlumno_GAs = new ArrayList<RelNombreAlumno_GA>();

        //ArrayList<PaseLista_DetalleLista> ArregloObjetos_ListView_PaseLista_DetalleLista;
        //ArregloObjetos_ListView_PaseLista_DetalleLista = new ArrayList<PaseLista_DetalleLista>();

        String SELECT_QUERY = "SELECT * FROM DetallePaseLista where id_paselista = "+id_paselista;
        cursor2 = BaseDatos01.rawQuery(SELECT_QUERY, null);
        String [] Arreglo = cursor2.getColumnNames();
        String Condenacion="";
        String CXX1="";
        String CXX2="";
        String Nombre_Alumnos="";
        if (cursor2.getCount() != 0) {
            if (cursor2.moveToFirst()) {
                Condenacion = "";

                do {

                    String C1 = cursor2.getString(cursor2.getColumnIndex("_id"));
                    int id_DetallePaseLista = ("".equals(C1.toString().trim()) ? 0 : Integer.parseInt(C1.toString().trim()));

                    String C2 = cursor2.getString(cursor2.getColumnIndex("id_GrupoAlumno"));

                    int id_GrupoAlumno = ("".equals(C2.toString().trim()) ? 0 : Integer.parseInt(C2.toString().trim()));

                    String C3 = cursor2.getString(cursor2.getColumnIndex("Estatus"));
                    int Estatus = ("".equals(C3.toString().trim()) ? 0 : Integer.parseInt(C3.toString().trim()));

                    // Consultar el nombre del alumno
                    String SELECT_QUERY3 = "SELECT * FROM GrupoAlumno where _id = "+id_GrupoAlumno;
                    Cursor cursorX = BaseDatos01.rawQuery(SELECT_QUERY3, null);
                    if (cursorX.getCount() != 0) {
                        if (cursorX.moveToFirst()) {
                            CXX1 = cursorX.getString(cursorX.getColumnIndex("id_alumno"));
                        }
                    }
                    cursorX.close();

                    String SELECT_QUERY4 = "SELECT * FROM Alumnos where _id = "+CXX1;
                    Cursor cursorY = BaseDatos01.rawQuery(SELECT_QUERY4, null);
                    if (cursorY.getCount() != 0) {
                        if (cursorY.moveToFirst()) {
                            CXX2 = cursorY.getString(cursorY.getColumnIndex("nombre_alumno"));
                        }
                    }
                    cursorY.close();



                    //PaseLista_DetalleLista OBJ_Temporal = new PaseLista_DetalleLista(id_DetallePaseLista,id_paselista,id_GrupoAlumno,CXX2,Estatus);
                    // Lista Externa
                    listRelNombreAlumno_GAs.add(new RelNombreAlumno_GA(id_DetallePaseLista,id_paselista,id_GrupoAlumno,CXX2,Estatus));
                    //PaseLista_DetalleLista OBJ_Temporal = new PaseLista_DetalleLista(id_DetallePaseLista,id_paselista,id_GrupoAlumno,CXX2,50);
                    //ArregloObjetos_ListView_PaseLista_DetalleLista.add(OBJ_Temporal);
                    //TV5.append(""+OBJ_Temporal);
                    //Nombre_Alumnos+=OBJ_Temporal;
                    //Nombre_Alumnos+="\t"+OBJ_Temporal.getName()+OBJ_Temporal.Asistencia()+" idDetPL:"+ OBJ_Temporal.get_id()+" idPL: "+OBJ_Temporal.get_id_PaseLista()+" idGA:"+OBJ_Temporal.get_id_GrupoAlumno()+"\n";

                    //for (int i = 0; i < Arreglo.length; i++)
                    //    Condenacion += cursor.getString(i) + "-";
                    //Condenacion += "\n";
                } while (cursor2.moveToNext());
            }
            //TV4.setText(Condenacion);
            //TV5.setText("En REPARACION !");
        }
        // Recrear el Adaptador !!!


        cursor2.close();

        return Nombre_Alumnos;
    }

    String ConsultaDetalleLista_SinAlumno (int id_paselista) {
        Cursor cursor2;

        listRelNombreAlumno_GAs_2 = new ArrayList<RelNombreAlumno_GA>();

        //ArrayList<PaseLista_DetalleLista> ArregloObjetos_ListView_PaseLista_DetalleLista;

        //ArregloObjetos_ListView_PaseLista_DetalleLista = new ArrayList<PaseLista_DetalleLista>();
        String SELECT_QUERY = "SELECT * FROM DetallePaseLista where id_paselista = "+id_paselista;
        cursor2 = BaseDatos01.rawQuery(SELECT_QUERY, null);
        String [] Arreglo = cursor2.getColumnNames();
        String Condenacion="";
        String CXX1="";
        String CXX2="";
        String Nombre_Alumnos="";
        if (cursor2.getCount() != 0) {
            if (cursor2.moveToFirst()) {
                Condenacion = "";

                do {

                    String C1 = cursor2.getString(cursor2.getColumnIndex("_id"));
                    int id_DetallePaseLista = ("".equals(C1.toString().trim()) ? 0 : Integer.parseInt(C1.toString().trim()));

                    String C2 = cursor2.getString(cursor2.getColumnIndex("id_GrupoAlumno"));

                    int id_GrupoAlumno = ("".equals(C2.toString().trim()) ? 0 : Integer.parseInt(C2.toString().trim()));

                    String C3 = cursor2.getString(cursor2.getColumnIndex("Estatus"));
                    int Estatus = ("".equals(C3.toString().trim()) ? 0 : Integer.parseInt(C3.toString().trim()));
/*
                    // Consultar el nombre del alumno
                    String SELECT_QUERY3 = "SELECT * FROM GrupoAlumno where _id = "+id_GrupoAlumno;
                    Cursor cursorX = BaseDatos01.rawQuery(SELECT_QUERY3, null);
                    if (cursorX.getCount() != 0) {
                        if (cursorX.moveToFirst()) {
                            CXX1 = cursorX.getString(cursorX.getColumnIndex("id_alumno"));
                        }
                    }
                    cursorX.close();
*/
/*                    String SELECT_QUERY4 = "SELECT * FROM Alumnos where _id = "+CXX1;
                    Cursor cursorY = BaseDatos01.rawQuery(SELECT_QUERY4, null);
                    if (cursorY.getCount() != 0) {
                        if (cursorY.moveToFirst()) {
                            CXX2 = cursorY.getString(cursorY.getColumnIndex("nombre_alumno"));
                        }
                    }
                    cursorY.close();
*/

                    listRelNombreAlumno_GAs_2.add(new RelNombreAlumno_GA(id_DetallePaseLista,id_paselista,id_GrupoAlumno,CXX2,Estatus));
                    //PaseLista_DetalleLista OBJ_Temporal = new PaseLista_DetalleLista(id_DetallePaseLista,id_paselista,id_GrupoAlumno,CXX2,Estatus);
                    //PaseLista_DetalleLista OBJ_Temporal = new PaseLista_DetalleLista(id_DetallePaseLista,id_paselista,id_GrupoAlumno,CXX2,50);
                    //ArregloObjetos_ListView_PaseLista_DetalleLista.add(OBJ_Temporal);
                    //TV5.append(""+OBJ_Temporal);
                    //Nombre_Alumnos+=OBJ_Temporal;
                    //Nombre_Alumnos+="\t"+OBJ_Temporal.getName()+OBJ_Temporal.Asistencia()+" idDetPL:"+ OBJ_Temporal.get_id()+" idPL: "+OBJ_Temporal.get_id_PaseLista()+" idGA:"+OBJ_Temporal.get_id_GrupoAlumno()+"\n";

                    //for (int i = 0; i < Arreglo.length; i++)
                    //    Condenacion += cursor.getString(i) + "-";
                    //Condenacion += "\n";
                } while (cursor2.moveToNext());
            }
            //TV4.setText(Condenacion);
            //TV5.setText("En REPARACION !");
        }
        // Recrear el Adaptador !!!


        cursor2.close();

        return Nombre_Alumnos;
    }



/*    void ConsultaDetalleLista_ConAlumno (int id_paselista) {

        Cursor cursor2;
        List<RelDetallePaseListaAlumno> listRelDetallePaseListaAlumnos = new ArrayList<RelDetallePaseListaAlumno>();

        ArregloObjetos_ListView_PaseLista_DetalleLista = new ArrayList<PaseLista_DetalleLista>();
        String SELECT_QUERY = "SELECT * FROM DetallePaseLista where id_paselista = "+id_paselista;
        cursor2 = BaseDatos01.rawQuery(SELECT_QUERY, null);
        String[] Arreglo = cursor2.getColumnNames();
        String Condenacion="";
        String CXX1="";
        String NombreAlumnoDetallePaseLista="";
        TV5.setText("");
        if (cursor2.getCount() != 0) {
            if (cursor2.moveToFirst()) {
                Condenacion = "";
                do {

                    String C1 = cursor2.getString(cursor2
                            .getColumnIndex("_id"));
                    int id_DetallePaseLista = ("".equals(C1.toString().trim()) ? 0 : Integer.parseInt(C1.toString().trim()));

                    String C2 = cursor2.getString(cursor2
                            .getColumnIndex("id_GrupoAlumno"));

                    int id_GrupoAlumno = ("".equals(C2.toString().trim()) ? 0 : Integer.parseInt(C2.toString().trim()));

                    String C3 = cursor2.getString(cursor2.getColumnIndex("Estatus"));
                    int Estatus = ("".equals(C3.toString().trim()) ? 0 : Integer.parseInt(C3.toString().trim()));

                    // Consultar el nombre del alumno
                    String SELECT_QUERY3 = "SELECT * FROM GrupoAlumno where _id = "+id_GrupoAlumno;
                    //tring SELECT_QUERY3 = "SELECT * FROM GrupoAlumno ";
                    Cursor cursorX = BaseDatos01.rawQuery(SELECT_QUERY3, null);
                    if (cursorX.getCount() != 0) {
                        if (cursorX.moveToFirst()) {
                            CXX1 = cursorX.getString(cursorX.getColumnIndex("id_alumno"));
                        }
                    }
                    cursorX.close();

                    String SELECT_QUERY4 = "SELECT * FROM Alumnos where _id = "+CXX1;
                    Cursor cursorY = BaseDatos01.rawQuery(SELECT_QUERY4, null);
                    if (cursorY.getCount() != 0) {
                        if (cursorY.moveToFirst()) {
                            NombreAlumnoDetallePaseLista = cursorY.getString(cursorY.getColumnIndex("nombre_alumno"));
                        }
                    }
                    cursorY.close();

                    // Original: Insertar directamente en el adaptador sin ordenar...
                    //PaseLista_DetalleLista OBJ_Temporal = new PaseLista_DetalleLista(id_DetallePaseLista,id_paselista,id_GrupoAlumno,NombreAlumnoDetallePaseLista,Estatus);
                    //ArregloObjetos_ListView_PaseLista_DetalleLista.add(OBJ_Temporal);
                    //TV5.append(""+OBJ_Temporal);

                    // Nuevos: Crear el listado, posteriormente ordenarlo e insertarlo en el adaptador

                    listRelDetallePaseListaAlumnos.add(new RelDetallePaseListaAlumno(id_DetallePaseLista,id_paselista,id_GrupoAlumno,NombreAlumnoDetallePaseLista,Estatus));




                } while (cursor2.moveToNext());
            }
        }
        // Ordenar el listado por nombre...
        Collections.sort(listRelDetallePaseListaAlumnos, new RelDetallePaseListaAlumnoChainedComparator(
                        new RelDetallePaseListaAlumnoNameComparator())
        );
        // Insertarlo en el adaptador...

        int ConteoEstudiantes=1;
        for (RelDetallePaseListaAlumno emp : listRelDetallePaseListaAlumnos) {
            //System.out.println(emp);
            PaseLista_DetalleLista OBJ_Temporal = new PaseLista_DetalleLista(emp.getIddpl(),emp.getIdpl(), emp.getIdga(), ""+ConteoEstudiantes+". "+emp.getName(), emp.getEstatus());
            ArregloObjetos_ListView_PaseLista_DetalleLista.add(OBJ_Temporal);
            TV5.append("" + OBJ_Temporal);
            ConteoEstudiantes++;

        }



        cursor2.close();
    }

*/


    //long InsertarGrupo(String NombreG) {
    long InsertaAlumnoEnGrupo () {
        long id = 0;


        AlertDialog.Builder alert = new AlertDialog.Builder(MX);
        alert.setTitle("Agregar Alumno a Grupo Existente"); //Set Alert dialog title here
        alert.setMessage("Nombre del Nuevo Alumno del Grupo [" + T4_3.getText().toString() + "]: "); //Message here

        // Set an EditText view to get user input
        final EditText input = new EditText(MX);
        alert.setView(input);

        alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                //You will get as string input data in this variable.
                // here we convert the input to a string and show in a toast.
                String Nombre = input.getEditableText().toString().toUpperCase();

                long id_alumno_long= InsertaEstudiante(Nombre);

                int id_grupo = 0; //Integer.parseInt(ET3.getText().toString().trim());
                int id_alumno = 0; //Integer.parseInt(ET4.getText().toString().trim());

                id_grupo = ("".equals(T4_1.getText().toString().trim()) ? 0 : Integer.parseInt(T4_1.getText().toString().trim()));
                id_alumno = (int) id_alumno_long;

                long idga = InsertarGrupoAlumno(id_grupo, id_alumno);


                //Toast.makeText(MX,srt,Toast.LENGTH_LONG).show();
            } // End of onClick(DialogInterface dialog, int whichButton)
        }); //End of alert.setPositiveButton
        alert.setNegativeButton("CANCELAR", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                // NO HACER NADA !!
                // Canceled.
                dialog.cancel();

            }
        }); //End of alert.setNegativeButton
        AlertDialog alertDialog = alert.create();
        alertDialog.show();

        id = id_grupo_temporal;
        return id;
    }

    void ConsultarGrupos () {
        ArregloObjetos_Grupos = new ArrayList<Grupo>();
        String C1, C2, C3, C4;
        String Fin = "";
        cursor = BaseDatos01.rawQuery("select * from " + TABLA_PRINCIPALA, null);

        if (cursor.getCount() != 0) {
            if (cursor.moveToFirst()) {
                do {
                    C1 = cursor.getString(cursor.getColumnIndex("_id"));

                    C2 = cursor.getString(cursor.getColumnIndex("nombre_grupo"));

                    Fin += C1 + "-" + C2 + "-" + "\n";

                    final Grupo ET1= new Grupo(
                            ("".equals(C1.toString().trim()) ? 0 : Integer.parseInt(C1.toString().trim())), // ID
                            C2); // Nombre GRUPO
                    ArregloObjetos_Grupos.add(ET1);


                } while (cursor.moveToNext());
            }
        }
        cursor.close();
    }

    long InsertarVacioGrupo() {

        long id = 0;


        AlertDialog.Builder alert = new AlertDialog.Builder(MX);
        alert.setTitle("Agregar Nuevo Grupo Vacío"); //Set Alert dialog title here
        alert.setMessage("Ingese el nombre del grupo"); //Message here

        // Set an EditText view to get user input
        final EditText input = new EditText(MX);
        alert.setView(input);

        alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                //You will get as string input data in this variable.
                // here we convert the input to a string and show in a toast.
                String Nombre;
                Nombre = input.getEditableText().toString().toUpperCase();


                id_grupo_temporal = 0;
                ContentValues valuesA = new ContentValues();
                valuesA.put("nombre_grupo", Nombre);
                id_grupo_temporal = BaseDatos01.insert(TABLA_PRINCIPALA, null, valuesA);
                // Actualizar los controles
                ConsultarGrupos();
                adapter_Grupo = new AdaptadorGrupo(MX, R.layout.fila_spinner_personal, ArregloObjetos_Grupos);
                adapter_Grupo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                SP1.setAdapter(adapter_Grupo);
                SP1.setSelection(adapter_Grupo.getCount() - 1);

                SP4.setAdapter(adapter_Grupo);
                SP4.setSelection(adapter_Grupo.getCount() - 1);

                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(CX, "Grupo ["+Nombre+"] vacío", duration);
                toast.show();



                //Toast.makeText(MX,srt,Toast.LENGTH_LONG).show();
            } // End of onClick(DialogInterface dialog, int whichButton)
        }); //End of alert.setPositiveButton
        alert.setNegativeButton("CANCELAR", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                // NO HACER NADA !!
                // Canceled.
                dialog.cancel();

            }
        }); //End of alert.setNegativeButton


        AlertDialog alertDialog = alert.create();
        alertDialog.show();

        id = id_grupo_temporal;
        return id;
    }

    long InsertarGrupo(String NombreG) {

        String Nombre = NombreG;
        id_grupo_temporal = 0;
        ContentValues valuesA = new ContentValues();
        valuesA.put("nombre_grupo", Nombre);
        id_grupo_temporal = BaseDatos01.insert(TABLA_PRINCIPALA, null, valuesA);
        // Actualizar los controles
        ConsultarGrupos();
        adapter_Grupo = new AdaptadorGrupo(MX, R.layout.fila_spinner_personal, ArregloObjetos_Grupos);
        adapter_Grupo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        SP1.setAdapter(adapter_Grupo);
        SP1.setSelection(0);

        SP4.setAdapter(adapter_Grupo);
        SP4.setSelection(0);



        return (id_grupo_temporal);
    }

    // url = file path or whatever suitable URL you want.
    public static String getMimeType(String url) {
        String type = null;
        String extension = MimeTypeMap.getFileExtensionFromUrl(url);
        if (extension != null) {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        }
        return type;
    }


    void ActualizarInformacionGrupoInterfaz(String Nombre_Grupo, String ID_Grupo) {
        //Toast.makeText(getApplicationContext(), "Seleccion del Spiner2-\nElemento [ " + position + "] Nombre: " + Nombre_Grupo + " Apellidos: " + ID_Grupo, Toast.LENGTH_LONG).show();
        T4_1.setText(ID_Grupo);
        T4_3.setText(Nombre_Grupo);
    }

    void ConsultarAlumnos () {
        ArregloObjetos_Estudiantes = new ArrayList<Estudiante>();
        String C1, C2, C3, C4;
        String Fin = "";
        Fin="";
        cursor = BaseDatos01.rawQuery("select * from "+TABLA_PRINCIPALB, null);

        if (cursor.getCount() != 0) {
            if (cursor.moveToFirst()) {
                do {
                    C1 = cursor.getString(cursor.getColumnIndex("_id"));

                    C2 = cursor.getString(cursor.getColumnIndex("nombre_alumno"));

                    Fin += C1 + "-" + C2 + "-" + "\n";

                    final Estudiante ET1= new Estudiante(
                            ("".equals(C1.toString().trim()) ? 0 : Integer.parseInt(C1.toString().trim())), // ID
                            C2); // Nombre GRUPO
                    ArregloObjetos_Estudiantes.add(ET1);


                } while (cursor.moveToNext());
            }
            //TV3.setText(Fin);
        }
        cursor.close();
    }

    long InsertaEstudiante(String NombreEstudiante) {
        ContentValues valuesC = new ContentValues();
        valuesC.put("nombre_alumno", NombreEstudiante);
        long ide = BaseDatos01.insert(TABLA_PRINCIPALB, null, valuesC);

        // Actualizar los Controles
        ConsultarAlumnos();
        adapter_Estudiante = new AdaptadorEstudiante(MX, R.layout.fila_spinner_estudiante, ArregloObjetos_Estudiantes);
        adapter_Estudiante.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        SP2.setAdapter(adapter_Estudiante);
        SP2.setSelection(0);

        adapter_Estudiante2 = new AdaptadorEstudiante(MX, R.layout.fila_spinner_estudiante, ArregloObjetos_Estudiantes);
        adapter_Estudiante2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        SP3.setAdapter(adapter_Estudiante2);
        SP3.setSelection(0);


        return ide;
    }

    void ConsultaGrupo_Alumno () {
        // Consulta de Grupos-Alumno
        String C1, C2, C3, C4;
        String Fin = "";

        Fin="";
        cursor = BaseDatos01.rawQuery("select * from "+TABLA_SECUNDARIA, null);

        if (cursor.getCount() != 0) {
            if (cursor.moveToFirst()) {
                do {
                    C1 = cursor.getString(cursor.getColumnIndex("_id"));

                    C2 = cursor.getString(cursor.getColumnIndex("id_grupo"));

                    C3 = cursor.getString(cursor.getColumnIndex("id_alumno"));

                    Fin += C1 + "-" + C2 + "-" + C3 + "-\n";

                } while (cursor.moveToNext());
            }
            T4_8.setText(Fin);
        }
        cursor.close();
    }

    long InsertarGrupoAlumno(int id_grupo, int id_alumno) {
        // Insertar el Alumno
        ContentValues valuesX;
        valuesX=new ContentValues();

        valuesX.put("id_grupo", id_grupo);
        valuesX.put("id_alumno", id_alumno);
        long idga = BaseDatos01.insert(TABLA_SECUNDARIA,null,valuesX);

        // Actualizar los Controles
        ConsultaGrupo_Alumno();
        // Los pasos subsecuentes son necesarios porque al hacer esto, forzosamente ya hubo (o a lo mejor no) un pase de lista anterior
        // Paso 1: Hacer una consulta de todos los pases de lista del grupo [para el grupo id:grupo]y obtener el listado....

        // Buscar los pases de lista
        cursor = BaseDatos01.rawQuery("select * from PaseLista where id_grupo = " + id_grupo, null);
        if (cursor.getCount() != 0) {
            if (cursor.moveToFirst()) {
                String C1 = "";
                String CT="";
                do {
                    C1 += cursor.getString(cursor.getColumnIndex("_id"))+"\n";
                    CT = cursor.getString(cursor.getColumnIndex("_id"))+"\n";

                    int NC = cursor.getColumnIndex("_id");
                    int id_paselista= 0; //Integer.parseInt(ET3.getText().toString().trim());
                    id_paselista= ("".equals(cursor.getString(NC).toString().trim()) ? 0 : Integer.parseInt(cursor.getString(NC).toString().trim()));


                    // Insertar el detalle GA correspondiente a cada PASE DE LISTA
                    ContentValues valuesXA;
                    valuesXA= new ContentValues();
                    valuesXA.put("id_paselista",id_paselista);
                    valuesXA.put("id_GrupoAlumno",idga);
                    valuesXA.put("Estatus",0); // FALTA POR DEFECTO
                    BaseDatos01.insert("DetallePaseLista",null,valuesXA);


                    // FINAL

                } while (cursor.moveToNext());
                //Toast.makeText(getApplicationContext(), "Pases de Lista Atrasados:  \n" + C1, Toast.LENGTH_SHORT).show();
            }


        } else {
            //Toast.makeText(getApplicationContext(), "No hay pases de lista atrasados del Grupo:  \n" , Toast.LENGTH_SHORT).show();
        }

        // De la escrutura bajarlo a la base de datos...





        // Para cada entrada de ese listado (id_paselista)=> hacer una insercion utilizando el idgrupoalumno  del paso 0

        return idga;
    }


    // Enviado a llamar despues de seleccionar un ARCHIVO con nombres de estudiantes ....
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // Check which request we're responding to
        int ConteoAlumnos = 0;

        String fileName="";
        switch (requestCode) {
            case 1: // Opcion de Crear Grupo Vacío
                if (resultCode == RESULT_OK) {
                    Uri uri = data.getData();
                    //Toast.makeText(getApplicationContext(),"Regreso OK de seleccion de ARchivo:",Toast.LENGTH_SHORT).show();
                    if (uri != null) {
                        //Toast.makeText(getApplicationContext(),"URI NO NULO:"+uri.getPath(),Toast.LENGTH_SHORT).show();
                        //if (uri.toString().startsWith("file:")) {
                            fileName = uri.getPath();
                            Toast.makeText(getApplicationContext(),"Archivo a Procesar:"+fileName,Toast.LENGTH_SHORT).show();

                            String FE = ( (getMimeType(fileName) == null) ? "CHINGO A SU MADRE" : getMimeType(fileName));
                            String Solo_Nombre=fileName.substring(fileName.lastIndexOf(File.separator)+1).replaceFirst("[.][^.]+$", "");

                            //Toast.makeText(getApplicationContext(),"Nombre:"+Solo_Nombre ,Toast.LENGTH_SHORT).show();

                            //Toast.makeText(CX, "IF REGRESAMOS!!!"+Solo_Nombre,  Toast.LENGTH_SHORT).show();

                            long idg = InsertarGrupo(Solo_Nombre);
                            ActualizarInformacionGrupoInterfaz(Solo_Nombre,""+idg);

                            /*File file = new File(fileName);
                            StringBuilder texto = new StringBuilder();
                            try {
                                BufferedReader br = new BufferedReader(new FileReader(file));
                                String line;

                                // Para cada estudiante, insertar e insertar grupo-estudiante

                                while ((line = br.readLine()) != null) {
                                    // Paso -1: Validar el formato del STRING
                                    // EStablecer un tamaño minimo de cadena
                                    if (line.trim().length() < 2) {
                                        // Linea en blanco => No hacer ni madres
                                        //Toast toast = Toast.makeText(context, "LINEA EN BLANDO",  Toast.LENGTH_SHORT);
                                        //toast.show();
                                    } else {
                                        ConteoAlumnos++;
                                        // Procesar los datos para convertir todo a mayusculas
                                        String Temporal = line.toUpperCase();

                                        // No es linea en blanco.. Ingresarlo
                                        // Paso 0: Insertar el estudiante (se asume que no esta)
                                        long ide = InsertaEstudiante(Temporal);
                                        // Paso 1: Hacer la asociación GrupoAlumno
                                        long idga = InsertarGrupoAlumno((int) idg, (int) ide);
                                    }

                                    //texto.append(line+"::"+line.trim().length()+"\n");


                                    //texto.append('\n');
                                }
                            }catch (IOException e) {
                                //You'll need to add proper error handling here
                                Toast.makeText(getApplicationContext(),"Valio Barriga:" ,Toast.LENGTH_SHORT).show();
                            } */
                            File file = new File(fileName);
                            //StringBuilder builder = new StringBuilder();
                            try {
                                BufferedReader br = new BufferedReader(new FileReader(file));
                                String line;
                                while ((line = br.readLine())!=null){
                                    ConteoAlumnos++;
                                    // Procesar los datos para convertir todo a mayusculas
                                    String Temporal = line.toUpperCase();

                                    // No es linea en blanco.. Ingresarlo
                                    // Paso 0: Insertar el estudiante (se asume que no esta)
                                    long ide = InsertaEstudiante(Temporal);
                                    // Paso 1: Hacer la asociación GrupoAlumno
                                    long idga = InsertarGrupoAlumno((int) idg, (int) ide);
                                    //builder.append(line);
                                    //builder.append("\n");
                                }
                                br.close();
                            }catch (Exception e){
                                //Log.e("main", " error is "+e.toString());
                                Toast.makeText(getApplicationContext(),"Valio Barriga:"+e.toString() ,Toast.LENGTH_SHORT).show();
                            }


                            Toast.makeText(CX, "Grupo ["+Solo_Nombre+"] con ["+ConteoAlumnos+"] alumnos fue agregado", Toast.LENGTH_SHORT).show();


                        //} else
                        //{ // uri.startsWith("content:")
/*                            Toast.makeText(CX, "ELSE REGRESAMOS!!!"+fileName,  Toast.LENGTH_SHORT).show();

                            Cursor c = getContentResolver().query(uri, null, null, null, null);

                            if (c != null && c.moveToFirst()) {

                                int id = c.getColumnIndex(MediaStore.Images.Media.DATA);
                                if (id != -1) {
                                    fileName = c.getString(id);
                                    String FE = ( (getMimeType(fileName) == null) ? "CHINGO A SU MADRE" : getMimeType(fileName));
                                    String Solo_Nombre=fileName.substring(fileName.lastIndexOf(File.separator)+1).replaceFirst("[.][^.]+$", "");


                                    Context context = getApplicationContext();
                                    CharSequence text = fileName;
                                    if (FE.equals("text/plain")) {
                                        // Insertar el Grupo....

                                        long idg = InsertarGrupo(Solo_Nombre);
                                        ActualizarInformacionGrupoInterfaz(Solo_Nombre,""+idg);

                                        File file = new File(fileName);
                                        StringBuilder texto = new StringBuilder();
                                        try {
                                            BufferedReader br = new BufferedReader(new FileReader(file));
                                            String line;

                                            // Para cada estudiante, insertar e insertar grupo-estudiante

                                            while ((line = br.readLine()) != null) {
                                                // Paso -1: Validar el formato del STRING
                                                // EStablecer un tamaño minimo de cadena
                                                if (line.trim().length()<2) {
                                                    // Linea en blanco => No hacer ni madres
                                                    //Toast toast = Toast.makeText(context, "LINEA EN BLANDO",  Toast.LENGTH_SHORT);
                                                    //toast.show();
                                                }
                                                else {
                                                    ConteoAlumnos++;
                                                    // Procesar los datos para convertir todo a mayusculas
                                                    String Temporal = line.toUpperCase();

                                                    // No es linea en blanco.. Ingresarlo
                                                    // Paso 0: Insertar el estudiante (se asume que no esta)
                                                    long ide = InsertaEstudiante(Temporal);
                                                    // Paso 1: Hacer la asociación GrupoAlumno
                                                    long idga = InsertarGrupoAlumno((int) idg,  (int) ide);
                                                }

                                                //texto.append(line+"::"+line.trim().length()+"\n");


                                                //texto.append('\n');
                                            }
                                            br.close();
                                        }
                                        catch (IOException e) {
                                            //You'll need to add proper error handling here
                                        }

                                        int duration = Toast.LENGTH_LONG;
                                        Toast toast = Toast.makeText(context, "Grupo ["+Solo_Nombre+"] con ["+ConteoAlumnos+"] alumnos fue agregado", duration);
                                        toast.show();



                                    }
                                    else /// No es un archivo de texto -> Volver a seleccionar
                                    {

                                    }
                                }
                            }  */
                        //}
                    }
                }
                break;
            case 2: // Actualizar controles...
                //Toast.makeText(CX, "Saliendo de Opcion 2",  Toast.LENGTH_SHORT).show();


                ActualizaEstadistica();
                ActualizarSpinnerAlumnos();
                break;
            case 3:  // Actualizar controles...
                //Toast.makeText(CX, "Saliendo de Opcion 3",  Toast.LENGTH_SHORT).show();
                ActualizaEstadistica();
                ActualizarSpinnerAlumnos ();
                break;
            default: break;
        }
    }


}
