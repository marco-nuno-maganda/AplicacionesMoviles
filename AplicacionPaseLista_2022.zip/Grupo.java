package com.example.aplicacionpaselista_2022;

/**
 * Created by marco on 26/08/15.
 */
public class Grupo {

    private int id;
    private String Nombre;

    public Grupo (int nid, String nNombre) {
        id = nid;
        Nombre= nNombre;
    }

    public String getNombre () { return Nombre; }
    public int getId () { return id; }

    public void setNombre (String N) { Nombre = N; }
    public void setId (int nid) { id= nid; }

}
