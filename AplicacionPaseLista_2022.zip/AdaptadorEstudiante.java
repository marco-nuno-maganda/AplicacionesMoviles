package com.example.aplicacionpaselista_2022;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by marco on 26/08/15.
 */
public class AdaptadorEstudiante extends ArrayAdapter<String> {
    private Activity activity;
    private ArrayList data;
    public Resources res;
    //SpinnerModel tempValues=null;
    Estudiante tempValues=null;
    LayoutInflater inflater;

    /*************  CustomAdapter Constructor *****************/
    public AdaptadorEstudiante(
            MainActivity activitySpinner,
            int textViewResourceId,
            ArrayList objects

    )
    {
        super(activitySpinner, textViewResourceId, objects);

        /********** Take passed values **********/
        activity = activitySpinner;
        data     = objects;


        /***********  Layout inflator to call external xml layout () **********************/
        inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public View getDropDownView(int position, View convertView,ViewGroup parent) {
        return getCustomView(position, convertView, parent);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return getCustomView(position, convertView, parent);
    }

    // This funtion called for each row ( Called data.size() times )
    public View getCustomView(int position, View convertView, ViewGroup parent) {

        /********** Inflate spinner_rows.xml file for each row ( Defined below ) ************/
        View row = inflater.inflate(R.layout.fila_spinner_estudiante, parent, false);

        /***** Get each Model object from Arraylist ********/
        tempValues = null;
        //tempValues = (SpinnerModel) data.get(position);
        tempValues = (Estudiante) data.get(position);

        TextView ID        = (TextView)row.findViewById(R.id.tv_id_estudiante);
        TextView NOM          = (TextView)row.findViewById(R.id.tv_nombre_estudiante);

        // Set values for spinner each row
        ID.setText(tempValues.getId()+"");
        NOM.setText(tempValues.getNombre());

        return row;
    }
}
