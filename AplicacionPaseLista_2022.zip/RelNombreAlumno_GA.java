package com.example.aplicacionpaselista_2022;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * Created by marco on 27/04/16.
 */
public class RelNombreAlumno_GA {
    private int id_DetallePaseLista;
    private int id_paselista;
    private int id_GA;
    private String nombre_alumno;
    private int Estatus;

    public RelNombreAlumno_GA(int iddpl, int idpl, int id_ga, String na, int estus) {
        this.id_DetallePaseLista = iddpl;
        this.id_paselista=idpl;
        this.id_GA=id_ga;
        this.nombre_alumno=na;
        this.Estatus=estus;
    }
    // getters and setters

    public String getName () { return this.nombre_alumno; }
    public int getEStatus () { return this.Estatus; }
    public int getId () { return this.id_GA; }


    public String toString() {
        return String.format("%s \t%d \t%d \t%d \t[%d]", nombre_alumno, id_GA, id_DetallePaseLista, id_paselista,Estatus);
    }
}

class RelNombreAlumno_GAChainedComparator implements Comparator<RelNombreAlumno_GA> {

    private List<Comparator<RelNombreAlumno_GA>> listComparators;

    @SafeVarargs
    public RelNombreAlumno_GAChainedComparator(Comparator<RelNombreAlumno_GA>... comparators) {
        this.listComparators = Arrays.asList(comparators);
    }

    @Override
    public int compare(RelNombreAlumno_GA emp1, RelNombreAlumno_GA emp2) {
        for (Comparator<RelNombreAlumno_GA> comparator : listComparators) {
            int result = comparator.compare(emp1, emp2);
            if (result != 0) {
                return result;
            }
        }
        return 0;
    }
}

class RelNombreAlumno_GANameComparator implements Comparator<RelNombreAlumno_GA> {
    @Override
    public int compare(RelNombreAlumno_GA emp1, RelNombreAlumno_GA emp2) {
        return emp1.getName().compareTo(emp2.getName());
    }
}