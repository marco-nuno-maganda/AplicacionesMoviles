package com.example.skybox_android;

public interface Shape {
    void draw(float[] viewMatrix, float[] projectionMatrix);
}
