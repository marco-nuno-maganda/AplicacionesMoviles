package com.example.skybox_android;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;

import java.util.ArrayList;
import java.util.List;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

//import me.huntto.gl.skybox.shape.Shape;

import static android.opengl.GLES20.GL_BACK;
import static android.opengl.GLES20.GL_BLEND;
import static android.opengl.GLES20.GL_CCW;
import static android.opengl.GLES20.GL_COLOR_BUFFER_BIT;
import static android.opengl.GLES20.GL_CULL_FACE;
import static android.opengl.GLES20.GL_DEPTH_BUFFER_BIT;
import static android.opengl.GLES20.GL_DEPTH_TEST;
import static android.opengl.GLES20.glClear;
import static android.opengl.GLES20.glClearColor;
import static android.opengl.GLES20.glCullFace;
import static android.opengl.GLES20.glEnable;
import static android.opengl.GLES20.glFrontFace;
import static android.opengl.GLES20.glViewport;
import static android.opengl.Matrix.perspectiveM;
import static android.opengl.Matrix.rotateM;
import static android.opengl.Matrix.setIdentityM;
import static android.opengl.Matrix.setLookAtM;

public class ShapeRenderer implements GLSurfaceView.Renderer {
    private static final boolean D = BuildConfig.DEBUG;
    private float[] mViewMatrix = new float[16];
    private float[] mProjectionMatrix = new float[16];

    private List<Shape> mShapes = new ArrayList<>();
    private InitGLCallback mInitGLCallback;

    private float mRotationX;
    private float mRotationY;
    private final float[] mMVPMatrix;
    private final float[] mFinalMVPMatrix;
    private final float[] mRotationMatrix;
    public float mCubeRotation;// Pesima práctica
    private Cube_Orig mCube;

    // Variables para hacer la vista dual
    public static float screenWidth;
    public static float screenHeight;


    public ShapeRenderer(InitGLCallback callback) {
        mInitGLCallback = callback;
        mMVPMatrix = new float[16];
        mFinalMVPMatrix = new float[16];
        mRotationMatrix = new float[16];

    }

    public void addShape(Shape shape) {
        mShapes.add(shape);
    }




    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
        glEnable(GL_DEPTH_TEST);

        glFrontFace(GL_CCW);
        glEnable(GL_CULL_FACE);
        glCullFace(GL_BACK);

        glEnable(GL_BLEND);

        if (mInitGLCallback != null) {
            mInitGLCallback.onInitGL();
        }

        mCube = new Cube_Orig();
    }

    public void handleTouchDrag(float deltaX, float deltaY) {
        mRotationX += deltaX / 16;
        mRotationY += deltaY / 16;

        if (mRotationY < -90) {
            mRotationY = -90;
        } else if (mRotationY > 90) {
            mRotationY = 90;
        }

        resetViewMatrix();
        rotateM(mViewMatrix, 0, -mRotationY, 1f, 0f, 0f);
        rotateM(mViewMatrix, 0, -mRotationX, 0f, 1f, 0f);
    }

    private void resetViewMatrix() {
        setLookAtM(mViewMatrix, 0,
                0f, 0f, -5f,
                0f, 0f, 1f,
                0f, 1f, 0f);
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        glViewport(0, 0, width, height);

        screenHeight = height;
        screenWidth = width;

        perspectiveM(mProjectionMatrix, 0, 60, (float) width / (float) height, 1f, 10f);

        resetViewMatrix();
        Matrix.multiplyMM(mMVPMatrix, 0, mProjectionMatrix, 0, mViewMatrix, 0);


    }

    @Override
    public void onDrawFrame(GL10 gl) {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


        // Apply the rotation.
        Matrix.setRotateM(mRotationMatrix, 0, mCubeRotation, 1.0f, 1.0f, 1.0f);
        Matrix.multiplyMM(mFinalMVPMatrix, 0, mMVPMatrix, 0, mRotationMatrix, 0);


        //GLES20.glViewport(0, 0, (int)screenWidth / 2, (int)screenHeight );

        GLES20.glViewport(0, 0, (int)screenWidth / 2, (int)screenHeight );


        for (Shape shape : mShapes) {
           shape.draw(mViewMatrix, mProjectionMatrix);
        }

        mCube.draw(mFinalMVPMatrix);

        GLES20.glViewport((int)screenWidth /2, 0, (int)screenWidth /2, (int)screenHeight );


        for (Shape shape : mShapes) {
            shape.draw(mViewMatrix, mProjectionMatrix);
        }

        mCube.draw(mFinalMVPMatrix);
    }

    public interface InitGLCallback {
        void onInitGL();
    }
}
